# 数据字段说明

- all_candidates.csv：每个候选唯一PID，APT是否解析、IFU是否确认、处理状态、原因、发现入口。非IFU计划也保留。
- all_ifu_proposals.csv：当前APT有IFU或MAST有IFU模式记录的并集；不要求执行或公开。
- exclusion_audit.csv / pending_review.csv：排除理由与待确认缺口。待确认不等于排除。
- corrections.csv：旧64条逐项对照及新增条目。旧字段保留作审计，不作为事实。
- coverage_by_cycle_type.csv：当前公开APT中Cycle/Category；空值对应未取得APT。Joint资格看发现入口，不覆盖APT的主Category。
- program_PID.json：公开APT当前版本解析，不是历史执行最终配置；targets包含其它模式、背景和目标组。
- enrich_PID.json：公开计划页与Visit接口原始状态，errors标记访问缺口。
- sources.csv / planned_observations.csv：网站相关/待确认条目的源与计划观测，中文列名；源表不把共享观测曝光重复加到多个源。
- publication_reviews.json：arxiv与STScI期刊书目题名对应的人工核对，期刊日期不等于arxiv首次公开时间。
- actual_exposures.csv：独立曝光ID、源、观测、visit、实际grating/filter、EFFEXPTM秒、开始UTC；保留去重依据文件。
- source_registry.json：有原文出处的红移与别名。计划近似红移不能当作统一精确谱线红移。
- reviews.json / paper_reviews.json：人工评级与核心论文方法复核。修改时附出处、章节和日期。
- catalog.json / catalog.js：前述数据的网页视图；每个源有证据、五项适用性与逐线名义覆盖。
- retrieval_log.jsonl：请求、条件、分页、UTC和文件SHA256；重试失败仍留日志，不代表最终仍失败。
- references_manifest.json：交付资料路径、大小与SHA256；用于确认快照未损坏。
- validation.json / browser_validation.json：数据检查和127个详情页的浏览器验收记录。

发现IFU、科学身份核实、可测梯度是三个不同判断。当前保留资料缺口；confidence不宣称全部科学性质核实。
