"""对比本次修订后的整站离线重建基准；不覆盖历史基准。"""
from pathlib import Path
import json,hashlib
from gradient_literature import read_catalog,digest
root=Path(__file__).resolve().parents[1]
baseline=root/'data/paper_summary_rebuild_baseline.json'
if not baseline.exists():baseline=root/'data/three_state_rebuild_baseline.json'
b=json.loads(baseline.read_text());c=read_catalog(root)
tests=[{'test':'重建一致：'+k,'pass':digest(c[k])==v} for k,v in b['keys'].items()]
tests += [{'test':'SVG一致：'+k,'pass':hashlib.sha256((root/'charts'/k).read_bytes()).hexdigest()==v} for k,v in b['chart_sha256'].items()]
out={'checked':'2026-10-12','passed':all(t['pass'] for t in tests),'tests':tests}
(root/'data/three_state_rebuild_validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
if not out['passed']:raise SystemExit(1)
