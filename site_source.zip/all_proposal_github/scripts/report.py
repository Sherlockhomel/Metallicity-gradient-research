from github_publish_finalize import read_catalog
"""从计划筛选、保留的检索审计及本次验收生成报告。"""
from pathlib import Path
import json,html,collections,csv,re
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'data';C=read_catalog(ROOT);S=C['stats'];e=html.escape
V=json.loads((D/'validation.json').read_text()) if (D/'validation.json').exists() else {};g=V.get('scientific_gaps',{})
B=json.loads((D/'browser_validation.json').read_text()) if (D/'browser_validation.json').exists() else {};fresh=B.get('checked')=='2026-10-04'
SS=C.get('source_statistics',{})
SV=json.loads((D/'source_statistics_validation.json').read_text()) if (D/'source_statistics_validation.json').exists() else {}
SB=json.loads((D/'source_statistics_browser_validation.json').read_text()) if (D/'source_statistics_browser_validation.json').exists() else {}
source_fresh=SB.get('passed',False) and SB.get('feature')=='source_statistics'
rows=list(csv.DictReader((D/'coverage_by_cycle_type.csv').open(encoding='utf-8-sig')))
table='<div class="tablewrap"><table><thead><tr>'+''.join('<th>'+e(x)+'</th>' for x in ['周期','APT类型','候选','解析','IFU'])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+e(r[k] or '未知')+'</td>' for k in ['cycle','category','candidates','apt_parsed','ifu'])+'</tr>' for r in rows)+'</tbody></table></div>'
body=f'''<div class="eyebrow">检索截止 2026-10-03 · 分级修订 2026-10-04</div><h1>计划筛选修订与验收报告</h1>
<section><h2>本次修订结果</h2><p>重新审阅126个旧目录项目，按科学源类型、红移和IFU配置筛选；现目录{S['site_count']}条，课题相关{S['scope']['课题相关']}、待确认{S['scope']['待确认']}。A级{S['grades'].get('A',0)}、B级{S['grades'].get('B',0)}、C级{S['grades'].get('C',0)}、未定级{S['grades'].get('未定级',0)}。单源可以A；混合项目有合格普通SFG则项目A，AGN/透镜子集仍B。未处理科学数据不影响评级。</p><p>1215 Himiko及5761 Wolfe盘按配置A；5761当前G395M支持N2，Hβ/[OIII]在波段外。4196 SPARKY在z≈2.3使用G395M，缺常用光学气相诊断，因此C。5917缺Hα但PRISM仍有Ne3O2，保留透镜B。9433 TheCliff采用计划目标z=3.55，排除引言比较对象z=7的误用。2905是SN Zwicky喷射物光谱，移至排除审计而保留原始资料。</p><p>逐项旧/新等级、说明和出处见<a href="data/classification_revision.csv">126项目修订清单</a>；可编辑数据在<a href="data/proposal_selection.json">人工分类表</a>。旧页面、数据和审计CSV保存在本地完整版all_proposal中的history/2026-10-03，原网站保留。</p></section>
<section><h2>新增等级计数与独立A源统计</h2><p>四级卡覆盖全目录{SS.get('proposal_count')}个项目，等级和原有分级一致。计数为至少{SS.get('minimum')}个独立A研究源，对照{SS.get('a_pointings')}条A类IFU指向；{SS.get('counted_records')}条记录包括普通单源和CGG-z5群体下限。Wolfe盘和REBELS重复观测合并，8512两对拼接合并后为8个星系，1554只计西伴星系，7014的CEERS3、4分开；YD混合视场与BR1202额外成员列待拆分，不猜数量。</p><p>{SS.get('numeric_count')}个独立源有逐源数值红移，按Δz=1左闭右开分箱；光谱、光度/计划估计和取得方式未说明分别标色。至少{SS.get('interval_minimum')}个源只有范围或共同近似值，单列区间图，不取中点。CGG-z5按计划至少6个成员、共同约z=5.2计入下限，不伪造六个精确红移。成员映射、计数与出处见<a href="data/independent_sources.json">可编辑独立源映射</a>、<a href="data/a_independent_sources.csv">独立A源CSV</a>、<a href="data/source_statistics.json">生成统计</a>。</p><p>新增统计数据检查：{'通过' if SV.get('passed') else '待完成'}；新增功能浏览器检查：{'通过' if source_fresh else '待完成'}。<a href="data/source_statistics_validation.json">统计验收</a> · <a href="data/source_statistics_browser_validation.json">实际浏览器验收</a>。本次修改前版本保存在本地完整版all_proposal中的history/2026-10-04-before-source-statistics；原始资料和旧审计保留。</p></section>
<section><h2>计划信息与论文</h2><p>源名、坐标、模式与grating/filter直接引用现有公开APT；源类型和红移引用计划摘要、观测说明、源表或已有论文。详情提供字段出处与位置，取消整体可信度标签。共同范围只显示为范围；计划缺失或边界不明的字段明确说明，不伪造每源数值。</p><p>IFU科学指向{g.get('science_pointings','待生成')}个；数值源红移{g.get('z_known','待生成')}个，计划范围/共同近似值{g.get('z_range','待生成')}个，未给出可计算数值{g.get('z_unknown','待生成')}个。这些数是指向数，包含候选及多重像，不是独立星系数。数值不足时，仅在计划明确高z与诊断设计的情况下按设计分级；其余保留具体缺失原因。</p><p>保留{S['core_papers']}篇核心论文的诊断、校准、分箱、结果与限制，区分整体丰度、二维分布与径向梯度。论文实际方法保留；是否已有论文或数据处理结果不作为评级门槛。官方书目仅表示PID关联，部分新预印本可能未收录。</p></section>
<section><h2>检索快照和访问审计</h2><p>本次没有重新全量检索。保留原2026-10-03快照：{S['official_pages']}个官方入口、{S['candidate_count']}个候选、{S['apt_parsed']}份解析APT、{S['ifu_count']}个确认IFU；官方表格PID的APT覆盖率100%。GO覆盖已公布Cycle1–5，另含GTO/ERS/DDT/Joint/Calibration及公开可发现的工程/调试计划。</p><p>MAST NIRSPEC/IFU为17884行/2页，NRS_IFU模式105495行/11页，历史NIRSPEC为7766行/1页。截止日前去重曝光{S['unique_exposures']}个，重复产品EFFEXPTM无冲突。曝光可能含背景/泄漏标定，不等于科学源净在源时间；当前APT不代替实际执行配置。</p><p>旧6245公开APT返回404；未执行且无归档记录的commissioning计划尚无独立批准全集，不能宣称绝对完整。PDF/Visit接口缺口及检索分页保留原日志；缺口集中在审计页。详见<a href="audit.html">审计页</a>、<a href="data/retrieval_log.jsonl">检索日志</a>及<a href="data/references_manifest.json">资料快照清单</a>。</p>{table}</section>
<section><h2>本次验收</h2><p>软件与数据验收：{'通过' if V.get('checked')=='2026-10-04' and V.get('software_data_pass') else '待完成本次检查'}。检查PID唯一、候选处理状态与来源、观测关联、曝光去重及秒单位、标量/范围红移波长计算、分类一致、单源及混合规则、PRISM替代路线、论文映射与本地资源。<a href="data/validation.json">详细数据验收</a>。</p><p>浏览器验收：{'已完成本次修订的详情、搜索筛选、导航、刷新、键盘和手机布局检查' if fresh else '本次页面回归检查待完成'}。<a href="data/browser_validation.json">详细浏览器记录</a>。页面不依赖fetch；预览工具禁止file://，双击场景仅做静态检查，未重新尝试受限协议。</p></section>
<section><h2>修改与交付</h2><p>网站、源码、数据、指南、验收报告及ZIP在原all_proposal目录。<a href="README.html">修改入口</a> · <a href="UPDATE_GUIDE.md">详细指南</a> · <a href="downloads/site_source.zip">源码ZIP</a>。没有重新全量检索、处理科学数据或发布网站。</p></section>'''
head=(ROOT/'index.html').read_text().split('<main id="main">')[0]
(ROOT/'verification_report.html').write_text(re.sub(r'<title>.*?</title>','<title>计划筛选修订与验收报告</title>',head)+'<main id="main" class="reading">'+body+'</main><footer>检索截止2026-10-03 · 分级修订2026-10-04</footer></body></html>')
(ROOT/'verification_report.md').write_text(f'''# 计划筛选修订与验收报告

检索截止2026-10-03；评级修订2026-10-04。本次审阅126个旧项目，现目录125条：A {S['grades'].get('A',0)}、B {S['grades'].get('B',0)}、C {S['grades'].get('C',0)}、未定级 {S['grades'].get('未定级',0)}。2905超新星喷射物项目移至排除审计。

分级只用源类型、红移和IFU诊断配置。单源可以A，混合项目按合格SFG归A并逐源保留B；缺Hα与探测器间隙风险不自动降级。计划字段直接引用并标明出处，真正缺失的字段单独说明。

数据验收：{'通过' if V.get('checked')=='2026-10-04' and V.get('software_data_pass') else '待完成'}；浏览器验收：{'完成' if fresh else '待完成'}。详见verification_report.html及data中的验收记录。file://场景仅静态检查。

历史页面、数据和审计表保存在本地完整版all_proposal中的history/2026-10-03；原网站和原始公开资料保留。检索快照2030候选、2029解析APT、449确认IFU。6245访问404与未执行commissioning全集缺口留在审计页。本次没有重新检索、处理科学数据或发布网站。
''')
with (ROOT/'verification_report.md').open('a') as f:
 f.write(f'\n本次新增统计：四级proposal卡覆盖{SS.get("proposal_count")}条；至少{SS.get("minimum")}个独立A源、{SS.get("a_pointings")}条A指向，{SS.get("numeric_count")}个数值红移及至少{SS.get("interval_minimum")}个范围/共同近似源。统计数据检查：{SV.get("passed",False)}；新增浏览器检查：{source_fresh}。独立源映射与统计CSV在data，修改前版在本地完整版all_proposal中的history/2026-10-04-before-source-statistics。\n')
print('report generated')

from github_publish_finalize import finalize
finalize(ROOT)
