from github_publish_finalize import read_catalog
from pathlib import Path
import json,html,re
ROOT=Path(__file__).resolve().parents[1]
C=read_catalog(ROOT);s=C['stats']
head=(ROOT/'index.html').read_text().split('<main id="main">')[0]
foot='</main><footer>检索截至2026-10-03 · 分级修订2026-10-04 · 资料和源码保存在同一目录</footer></body></html>'
def page(name,title,body):
 text=re.sub(r'<title>.*?</title>','<title>'+title+'</title>',head)+'<main id="main" class="reading"><div class="eyebrow">JWST IFU · PROPOSAL SELECTION</div><h1>'+title+'</h1>'+body+foot
 (ROOT/name).write_text(text)
page('criteria.html','按计划条件分级', '''
<p>本网站按<strong>计划中的科学源类型、红移与IFU配置</strong>筛选气相金属丰度研究候选。分级不要求已有科学数据处理结果；单源和多源采用同一条件。这是本网站的课题选择，不是STScI官方评级。</p>
<section><h2>A / B / C / 未定级</h2><div class="grid">
<article><h3>A · 普通星形成源</h3><p>至少一个z&gt;2普通星形成星系，其IFU配置支持可用的气相丰度诊断。一个合格源即可进入A。Merger、特殊选样和已有梯度只作标签。</p></article>
<article><h3>B · AGN或透镜等额外处理</h3><p>配置有分析潜力，但对象为AGN/类星体宿主、强透镜星系或计划明确的混合电离气体。AGN需分离核区及其它电离来源；强透镜需做源平面处理。多重像仍关联同一星系。</p></article>
<article><h3>C · 明确的物理或配置限制</h3><p>计划明确研究静止星系的恒星性质、前景透镜恒星动力学、超新星喷射物，或IFU配置缺少本课题的气相丰度诊断。每个C项目注明具体目标与限制；源少不构成C理由。</p></article>
<article><h3>未定级 · 关键计划信息缺失</h3><p>数值红移、源身份或配置不足以判断条件，例如只给z≈2且无法确定是否严格z&gt;2。尚未处理科学数据不构成未定级理由。计划资料足够时直接分级并引用。</p></article></div>
<p>混合项目至少有一个合格A类源，项目显示A，并在详情逐源列出适用对象。其余AGN/透镜目标保留B。定位、背景、标定、其它模式目标和目标组本身不参与评级。项目包含的指向数不等于独立星系数。</p></section>
<section><h2>可用诊断如何判断？</h2><p>用源红移计算λobs=λrest×(1+z)，与该源全部IFU grating/filter的名义范围比较。当前筛选使用R3（[OIII]5007/Hβ）、R23（[OII]+[OIII]/Hβ）、Ne3O2（[NeIII]/[OII]）、N2（[NII]/Hα）、O3N2及氧温度线组合。路线覆盖表示可设计分析，不保证实际谱线检测或校准精度；R3/R23的支选择等限制在论文及后续分析中说明。</p>
<p>缺Hα不自动降级：若蓝端R3、R23或Ne3O2可用，仍满足诊断配置条件。PRISM的Hα/[NII]可能混线，不能仅凭PRISM覆盖判N2/O3N2可用；可选择其它被覆盖的诊断。不同红移段可能采用不同路线。只有共同红移范围时显示范围，不伪造每源精确值；范围内不能确定可用路线的源单独说明。</p>
<p>探测器间隙风险根据官方30切片表显示，不能直接视为实际谱线缺失。实际损失取决于切片位置与dither；不会仅凭风险标记降级。页面不估算空间分辨条件，也不据此筛选。</p>
<p><a href="https://jwst-docs.stsci.edu/jwst-near-infrared-spectrograph/nirspec-operations/nirspec-ifu-operations/nirspec-ifu-wavelength-ranges-and-gaps">官方波长与间隙表</a> · <a href="data/proposal_selection.json">逐项目人工摘录</a> · <a href="scripts/proposal_selection.py">分级计算源码</a></p></section>
<section><h2>具体例子与研究参照</h2><p><a href="detail.html?pid=1215">1215 Himiko</a>：单个普通SFG仍可A，PRISM/G395H有气相诊断。<a href="detail.html?pid=5761">5761 Wolfe盘</a>：单源A；当前G395M的Hα/[NII]可用，Hβ/[OIII]在该配置外。<a href="detail.html?pid=4196">4196 SPARKY</a>：z≈2.3的G395M主要测近红外线；Hβ/[OIII]/Hα约1.60/1.65/2.17µm低于配置下限，因此C。<a href="detail.html?pid=4528">4528</a>：合格SFG使项目显示A，QSO及透镜子集逐源B。</p>
<p><a href="detail.html?pid=3045">3045</a>可作统一星形成样本与重复观测关联的参照；<a href="detail.html?pid=1893">1893</a>已有径向梯度论文，按未透镜/透镜源分别评级；<a href="detail.html?pid=2957">2957</a>的低丰度特殊选样保留标签；<a href="detail.html?pid=1355">1355</a>为透镜二维丰度分析参照。论文实际采用的匹配与分箱方法在论文介绍中保留，整体丰度、二维分布和径向梯度分别注明。</p></section>''')
page('audit.html','全量检索与审计记录',f'''
<p>检索截止2026-10-03；本次2026-10-04只修订计划条件筛选，未重新全量检索。官方批准目录、MAST观测模式和历史仪器名称取并集；旧64条只作对照。</p>
<section><h2>检索方法与覆盖</h2><p>{s['official_pages']}个官方入口涵盖已公布GO Cycle1–5，以及GTO、ERS、DDT、Joint、Calibration；全部表格候选均尝试检查APT观测模板，标题不含IFU也检查。混合模式中任一NirspecIFUSpectroscopy即纳入。候选{s['candidate_count']}，已解析{s['apt_parsed']}，确认IFU {s['ifu_count']}。</p>
<p>独立MAST CAOM的NIRSPEC/IFU查询17884行/2页；NRS_IFU观测模式105495行/11页；历史NIRSPEC名称7766行/1页、45个PID，补查14个候选。未检出MAST不能判为非IFU或未执行。原始曝光ID去重，两个探测器和多种处理产品只计一次，EFFEXPTM单位秒。</p><p><a href="https://www.stsci.edu/jwst/science-execution/approved-programs">批准计划入口</a> · <a href="https://outerspace.stsci.edu/spaces/MASTDOCS/pages/176435458/JWST%2BInstrument%2BNames">仪器名称说明</a></p><div id="auditStats"></div></section>
<section><h2>访问缺口与历史保留</h2><p>旧6245的公开APT返回404，尚无IFU证据，保留待确认。公开commissioning/工程计划通过MAST发现并查APT；尚无独立批准全集覆盖未执行且无归档记录的调试计划。部分PDF/Visit接口访问失败；具体记录见data/apt_audit.json及data/enrich_PID.json。APT为当前公开版本，实际执行配置需结合MAST曝光。</p><p>请求条件、分页、数量、UTC和哈希见<a href="data/retrieval_log.jsonl">检索日志</a>及<a href="data/coverage_by_cycle_type.csv">周期类型覆盖表</a>。原始资料在references；旧页面、分类数据和审计清单保留在本地完整版all_proposal中的history/2026-10-03。2905为SN Zwicky喷射物研究，已从研究目录移入排除审计；126个旧目录项目全部重新审阅，现目录125条。</p><p>名称、坐标、红移和配置直接引用计划或论文。计划未给数值时注明；论文官方索引可能滞后，PID关联不自动证明IFU、具体源或梯度方法。</p></section>
<section><h2>下载清单</h2><p class="external"><a href="data/all_candidates.csv">所有候选</a><a href="data/all_ifu_proposals.csv">IFU全集</a><a href="data/exclusion_audit.csv">排除审计</a><a href="data/pending_review.csv">待确认</a><a href="data/classification_revision.csv">本次逐项目评级修订</a><a href="data/corrections.csv">原检索更正</a><a href="verification_report.html">验收报告</a><a href="data/actual_exposures.csv">唯一曝光</a></p></section>
<section><h2>逐项追溯</h2><div class="filters auditfilter"><label class="search">搜索PID / 原因<input id="aq" type="search" placeholder="查找所有候选，包括排除计划"></label><label>处理<select id="ad"><option value="">全部</option><option>课题相关</option><option>待确认</option><option>排除</option></select></label><label><span>范围</span><span><input id="ai" type="checkbox"> 只看确认IFU</span></label><span id="auditCount" aria-live="polite"></span></div><div id="auditRows"></div></section>''')
page('README.html','源码、数据与修改指南','''
<p>双击index.html即可使用静态页面，列表与详情不依赖网络请求；外部资料链接需要网络。请保留整个文件夹。</p>
<section><h2>怎样修改</h2><ol><li>外观：styles.css；首页：index.html；筛选和详情显示：app.js。</li><li>分类标准、审计页和本页由scripts/pages.py生成，请修改脚本中的文字，防止重建覆盖。</li><li><strong>源类型、红移范围、标签、逐项目说明：</strong>data/proposal_selection.json。programs下PID对应计划；sources按APT Target编号覆盖特定源，包含source_type、z或z_range、出处和note。</li><li>已测逐源红移、规范名、别名与对应论文出处：data/source_registry.json。共同计划范围不能填成每源精确测量。</li><li>独立源计数、拼接及群体拆分：data/independent_sources.json；scripts/source_statistics.py生成统计JSON、CSV和SVG。修改minimum、lower_bound、members及身份/红移出处后重建；不要手改首页数字。</li><li>论文方法：data/paper_reviews.json；发表记录：data/publication_reviews.json。分箱和实际采用的方法独立于计划评级。</li><li>scripts/proposal_selection.py按源类型及可用诊断生成等级；scripts/build_catalog.py生成data/catalog.json、离线catalog.js和CSV。data/reviews.json是兼容输出与排除原因表，等级修改请使用proposal_selection.json。</li></ol><p><a href="UPDATE_GUIDE.md">详细修改与重建指南</a> · <a href="data/proposal_selection.json">可编辑人工分类数据</a></p></section>
<section><h2>文件与交付</h2><p>data存放原始解析字段、人工摘录、页面数据及审计CSV；references保留原始APT/PDF和查询响应；scripts为检索、构建和验收源码；本地完整版all_proposal中的history/2026-10-03保留旧页面及审计数据；本地完整版all_proposal中的history/2026-10-04-before-source-statistics保留本次统计修改前版本。</p><p><a href="downloads/site_source.zip">GitHub精简版源码ZIP</a> · <a href="data/catalog.json">页面数据</a> · <a href="data/a_independent_sources.csv">独立A源CSV</a> · <a href="data/source_statistics.json">统计数据</a> · <a href="verification_report.html">验收报告</a></p><p>浏览无需安装；重建需Python，重新检索依赖见requirements.txt。检索截止仍为2026-10-03，本次分类修订2026-10-04；没有重新检索、处理科学FITS或发布网站。网站代码可自由修改，官方文件与论文仍归原作者或机构。</p></section>''')
print('pages generated')

from github_publish_finalize import finalize
finalize(ROOT)
