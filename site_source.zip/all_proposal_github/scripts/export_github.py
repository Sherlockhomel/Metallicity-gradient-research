"""导出GitHub Pages副本：保留全部研究内容与独立重建能力，不改变原目录。"""
from pathlib import Path
import argparse,csv,gzip,hashlib,json,re,shutil
from github_publish_finalize import finalize,normalize,signature,EDITABLE,read_catalog

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def export(source,dest):
    source=source.resolve();dest=dest.resolve()
    if dest.exists():raise SystemExit('输出目录已存在；请使用新目录，避免覆盖后续人工修改。')
    if dest==source or source in dest.parents or dest in source.parents:raise SystemExit('源目录和输出目录不能相互嵌套。')
    for name in ['data','scripts','references','charts','downloads']: (dest/name).mkdir(parents=True,exist_ok=True)
    c=read_catalog(source)
    total=sum(f.stat().st_size for f in source.rglob('*') if f.is_file())
    baseline={'checked':'2026-10-07','cutoff':c['stats']['cutoff'],'stats':c['stats'],'program_grades':[{'pid':p['pid'],'grade':p['grade'],'sources':[[t['number'],t['source_grade']] for t in p['sources']]} for p in c['programs']],
      'signatures':{k:signature(c[k]) for k in ['stats','programs','audit','core_papers','source_statistics']}}
    (dest/'data/github_export_baseline.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2))
    for f in list(source.glob('*.html'))+[source/'app.js',source/'statistics.js',source/'styles.css',source/'requirements.txt']:
        if f.exists():shutil.copy2(f,dest/f.name)
    for f in (source/'charts').iterdir():
        if f.is_file():shutil.copy2(f,dest/'charts'/f.name)
    for f in (source/'scripts').glob('*.py'):shutil.copy2(f,dest/'scripts'/f.name)
    for f in (source/'data').iterdir():
        if not f.is_file() or f.name in ['catalog.js','package_validation.json']:continue
        out=dest/'data'/f.name
        if f.suffix=='.json' and f.name!='references_manifest.json':
            v=normalize(json.loads(f.read_text()))
            out.write_text(json.dumps(v,ensure_ascii=False,indent=2) if f.name in EDITABLE else json.dumps(v,ensure_ascii=False,separators=(',',':')))
        elif f.suffix=='.csv':
            with f.open(encoding='utf-8-sig',newline='') as src,out.open('w',encoding='utf-8-sig',newline='') as dst:
                rows=csv.DictReader(src);w=csv.DictWriter(dst,fieldnames=rows.fieldnames);w.writeheader()
                for row in rows:
                    for k,v in row.items():
                        if v and v[:1] in '[{':
                            try:row[k]=json.dumps(normalize(json.loads(v)),ensure_ascii=False)
                            except ValueError:pass
                        elif v:row[k]=normalize(v)
                    w.writerow(row)
        else:shutil.copy2(f,out)
    compressed=[]
    (dest/'data/github_archive_order.json').write_text(json.dumps([str(f.relative_to(source)) for f in (source/'references').glob('mast_*.json')],ensure_ascii=False))
    for f in sorted((source/'references').iterdir()):
        if not f.is_file():continue
        if f.name.startswith('mast_') and f.suffix=='.json':
            raw=f.read_bytes();out=dest/'references'/(f.name+'.gz')
            with out.open('wb') as fd:
                with gzip.GzipFile(filename='',mode='wb',fileobj=fd,compresslevel=9,mtime=0) as g:g.write(raw)
            compressed.append({'original_file':str(f.relative_to(source)),'published_file':str(out.relative_to(dest)),'original_bytes':len(raw),'published_bytes':out.stat().st_size,'uncompressed_sha256':hashlib.sha256(raw).hexdigest(),'published_sha256':sha(out)})
        elif f.name.startswith('bibliography_') and f.suffix=='.json' and f.name!='bibliography_all.json':
            (dest/'references'/f.name).write_text(json.dumps(json.loads(f.read_text()),ensure_ascii=False,separators=(',',':')))
        elif f.name.startswith('paper_') and f.suffix=='.txt':shutil.copy2(f,dest/'references'/f.name)
    # 使用脚本自身旁边的发布工具，使导出可再次执行。
    here=Path(__file__).resolve().parent
    for name in ['github_publish_finalize.py','export_github.py','validate_github.py','github_package.py']:
        shutil.copy2(here/name,dest/'scripts'/name)
    # 原构建流程读取无损gz缓存；按原始归档顺序去重，保留观测字段。
    p=dest/'scripts/build_catalog.py';s=p.read_text()
    s=s.replace('import json,re,csv,collections,datetime,math','import json,re,csv,collections,datetime,math,gzip')
    s=s.replace('def read(p,default=None):return json.loads(p.read_text()) if p.exists() else default',"def read(p,default=None):\n if not p.exists() and p.with_suffix(p.suffix+'.gz').exists():p=p.with_suffix(p.suffix+'.gz')\n if not p.exists():return default\n return json.loads(gzip.open(p,'rt',encoding='utf-8').read() if p.suffix=='.gz' else p.read_text())")
    s=s.replace('inst=read(D/',"def archive_files(pattern):\n order=read(D/'github_archive_order.json',[]);priority={name.removesuffix('.gz'):i for i,name in enumerate(order)}\n return sorted(R.glob(pattern+'*'),key=lambda f:priority.get(str(f.relative_to(ROOT)).removesuffix('.gz'),99999))\ninst=read(D/",1)
    for pattern in ['mast_legacy_NIRSPEC_*.json','mast_NIRSPEC_IFU_*.json','mast_NRS_IFU_*.json']:s=s.replace("R.glob('"+pattern+"')","archive_files('"+pattern+"')")
    s=s.replace("old=read(ROOT/'history/2026-10-03/data/catalog.json',{});oldp={p['pid']:p for p in old.get('programs',[])}", "old=None;oldp={}  # 既有126项目更正CSV已随发布副本保留；不重新构造已移出的历史资料。")
    s += '\nfrom github_publish_finalize import finalize\nfinalize(ROOT)\n'
    p.write_text(s)
    # 无历史大目录时仍使用小型等级基准验收。
    p=dest/'scripts/validate_source_statistics.py';s=p.read_text()
    s=s.replace("old=json.loads((root/'history/2026-10-04-before-source-statistics/data/catalog.json').read_text())", "old=json.loads((root/'data/github_export_baseline.json').read_text())")
    s=s.replace("[(p['pid'],p['grade'],[(t['number'],t['source_grade']) for t in p['sources']]) for p in old['programs']]", "[(p['pid'],p['grade'],[tuple(t) for t in p['sources']]) for p in old['program_grades']]")
    p.write_text(s)
    for name in ['pages.py','report.py']:
        p=dest/'scripts'/name;s=p.read_text()
        s=s.replace('history/2026-10-04-before-source-statistics','本地完整版all_proposal中的history/2026-10-04-before-source-statistics').replace('history/2026-10-03','本地完整版all_proposal中的history/2026-10-03')
        s=s.replace('href="jwst_ifu_site_source.zip"','href="downloads/site_source.zip"').replace('完整网站与源码ZIP','GitHub精简版源码ZIP')
        s += '\nfrom github_publish_finalize import finalize\nfinalize(ROOT)\n';p.write_text(s)
    for name in ['pages.py','report.py','validate.py','validate_source_statistics.py']:
        p=dest/'scripts'/name;s=p.read_text();s='from github_publish_finalize import read_catalog\n'+s
        for literal in ["json.loads((ROOT/'data/catalog.json').read_text())","json.loads((D/'catalog.json').read_text())"]:s=s.replace(literal,'read_catalog(ROOT)')
        s=s.replace("json.loads((root/'data/catalog.json').read_text())",'read_catalog(root)');p.write_text(s)
    # package入口用发布副本专用实现，不重新收入完整缓存或历史备份。
    (dest/'scripts/package.py').write_text('from github_package import package\nfrom pathlib import Path\npackage(Path(__file__).resolve().parents[1])\n')
    p=dest/'app.js';s=p.read_text()
    s=s.replace("${p.access_errors.pdf?link('https://www.stsci.edu/jwst-program-info/download/jwst/pdf/'+p.pid+'/','官方PDF'):link('references/proposal_'+p.pid+'.pdf','本地公开 PDF')}","${link('https://www.stsci.edu/jwst-program-info/download/jwst/pdf/'+p.pid+'/','官方 PDF ↗')}")
    # 页面中的出处统一使用官方APT；全部解析字段仍本地可下载。
    p.write_text(s)
    (dest/'.nojekyll').touch()
    (dest/'.gitignore').write_text('__pycache__/\n*.pyc\n.DS_Store\n*.tmp\n/history/\n/references/apt_*.aptx\n/references/proposal_*.pdf\n/jwst_ifu_site_source.zip\n')
    baseline_paths=['index.html','app.js','statistics.js','styles.css','data/catalog.json','data/proposal_selection.json','data/independent_sources.json','jwst_ifu_site_source.zip']
    meta={'checked':'2026-10-07','source':'本地完整版all_proposal','source_bytes':total,'preserved_source_hashes':{n:sha(source/n) for n in baseline_paths},'compressed_metadata':compressed,'notes':['原APT/PDF与历史备份不复制；使用官方计划资料链接','MAST响应无损gzip；论文文本、书目、全部解析JSON和审计CSV保留','检索截止及所有研究数据保持原快照；不发布网站']}
    (dest/'data/github_export_manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
    finalize(dest)
    print(json.dumps({'output':str(dest),'files':sum(f.is_file() for f in dest.rglob('*')),'bytes':sum(f.stat().st_size for f in dest.rglob('*') if f.is_file()),'compressed_mast_files':len(compressed)},ensure_ascii=False,indent=2))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--source',type=Path,default=Path('../all_proposal'));a.add_argument('--output',type=Path,required=True);args=a.parse_args();export(args.source,args.output)
