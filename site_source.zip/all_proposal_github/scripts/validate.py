from github_publish_finalize import read_catalog
"""离线验收：关联、覆盖、分级与页面回归；不依赖科学数据处理。"""
from pathlib import Path
import json,collections,re,math
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'data'
C=read_catalog(ROOT);P=C['programs'];A=C['audit'];M={p['pid']:p for p in P};tests=[]
def check(name,ok,detail=''):tests.append({'test':name,'pass':bool(ok),'detail':detail})
check('PID唯一',len(M)==len(P))
check('全部126个旧项目重新审阅',len(json.loads((D/'proposal_selection.json').read_text())['programs'])==126 and len(list(__import__('csv').DictReader((D/'classification_revision.csv').open(encoding='utf-8-sig'))))==126)
check('所有候选都有处理记录',len({a['pid'] for a in A})==C['stats']['candidate_count'] and all(a['disposition'] in ['课题相关','待确认','排除'] for a in A))
check('IFU发现可追溯',all(a['source'] or a['discovery_sources'] for a in A if a['ifu']))
check('目录仅含相关或待确认IFU',all(p['ifu_confirmed'] and p['scope'] in ['课题相关','待确认'] for p in P))
check('所有详情核心字段存在',all(p['title'] and p['pi'] and p['sources'] and p['observations'] for p in P))
check('分类数量一致',dict(collections.Counter(p['grade'] for p in P))==C['stats']['grades'] and sum(C['stats']['grades'].values())==len(P))
check('观测编号去重',all(len({o['number'] for o in p['observations']})==len(p['observations']) for p in P))
check('观测目标及目标组关联有效',all(o['target_number'] in {s['number'] for s in p['sources']} for p in P for o in p['observations']) and all(set(t.get('group_members',[]))<={s['number'] for s in p['sources']} for p in P for t in p['sources']))
check('源与观测关联有效',all(set(t['observations'])<={o['number'] for o in p['observations']} for p in P for t in p['sources']))
check('曝光唯一及秒单位',all(len({e['exposure'] for e in p['exposure_records']})==len(p['exposure_records']) and all(e['seconds']>=0 and math.isfinite(e['seconds']) for e in p['exposure_records']) for p in P))
check('重复产品曝光值无冲突',C['stats']['exposure_conflicts']==0)
lines={x['name']:x['rest_um'] for x in json.loads((D/'lines.json').read_text())['lines']}
def wave_ok(t,l):
 if t['z'] is not None:return abs(l['wavelength_um']-(1+t['z'])*lines[l['line']])<.000006
 if t['z_range']:return l['wavelength_um'] is None and all(abs(w-(1+z)*lines[l['line']])<.000006 for w,z in zip(l['wavelength_range_um'],t['z_range']))
 return False
check('标量与范围红移的波长计算正确',all(wave_ok(t,l) for p in P for t in p['sources'] for l in t['coverage']))
check('红移及类型均有出处',all(t['type_evidence'].get('source') and t['type_evidence'].get('locator') and (not(t['z'] is not None or t['z_range']) or (t['z_evidence'] and t['z_evidence'].get('source') and t['z_evidence'].get('locator'))) for p in P for t in p['sources']))
check('单源Himiko与Wolfe盘均A',M['1215']['grade']=='A' and M['5761']['grade']=='A')
check('混合项目有合格SFG则A',all(p['grade']=='A' for p in P if any(t['source_grade']=='A' for t in p['sources'])))
check('AGN与透镜不被误标为源A',all(t['source_type'] in ['星形成星系','同一视场含星形成分量与AGN'] for p in P for t in p['sources'] if t['source_grade']=='A'))
check('1264的HFLS3及SPT0311源B',all(t['source_grade']=='B' for t in M['1264']['sources'] if t['number'] in ['9','10']))
check('2957透镜子集不误归源A',all(t['source_grade']=='B' for t in M['2957']['sources'] if t['number'] in ['3','4','5','7']))
check('1554混合系统仅星形成分量A',M['1554']['grade']=='A' and any(t['source_grade']=='A' and t['components'] for t in M['1554']['sources']) and any(t['source_grade']=='B' for t in M['1554']['sources']))
check('4196为配置限制C',M['4196']['grade']=='C' and '1.60/1.65/2.17' in M['4196']['grade_reason'])
check('每个C都有具体目标与原因',all(p['grade_reason'] and any(t['source_grade']=='C' and t['selection_reason'] and t['setups'] for t in p['sources']) for p in P if p['grade']=='C'))
check('PRISM单独不认作N2/O3N2',all(not({'N2','O3N2'}&set(t['diagnostics'])) for p in P for t in p['sources'] if t['setups'] and all(s.startswith('PRISM') for s in t['setups'])))
check('5917缺Hα仍可蓝端诊断B',M['5917']['grade']=='B' and any('Ne3O2' in t['diagnostics'] for t in M['5917']['sources']))
check('2905进入排除审计', '2905' not in M and any(a['pid']=='2905' and a['disposition']=='排除' and 'SN' in a['reason'] for a in A))
check('9433红移源表纠正',any(t['z']==3.55 for t in M['9433']['sources'] if t['ifu_science_pointing']))
check('核心论文PID映射与原文位置有效',all(p['pid'] in a['pids'] and a['locator'] and a['checked'] for p in P for a in p['papers']))
app=(ROOT/'app.js').read_text();idx=(ROOT/'index.html').read_text();pages=''.join(f.read_text() for f in ROOT.glob('*.html'))
check('删除旧页面要求和列',not any(x in pages+app for x in ['天然适合','APT延展标记','PSF尺度 /','psf_estimate_arcsec','关键字段核实记录','新增目录条目','coverageNote','未核实']))
check('首页标题与三项统计', '<title>Metallicity Gradient Research</title>' in idx and '<h1>Metallicity Gradient Research</h1>' in idx and 'repeat(3,1fr)' in (ROOT/'styles.css').read_text() and 'C.stats.new_count' not in app)
check('离线加载无fetch','fetch(' not in app and 'catalog.js' in idx and 'catalog.js' in (ROOT/'detail.html').read_text())
missing=[]
for f in ROOT.glob('*.html'):
 for target in re.findall(r'(?:href|src)="([^"#]+)"',f.read_text()):
  if target.startswith(('http','mailto','data:')):continue
  path=target.split('?')[0].split('#')[0]
  if path and not(ROOT/path).exists() and not path.endswith('.zip'):missing.append((f.name,path))
check('本地资源链接存在',not missing,missing)
from validate_source_statistics import validate as validate_source_stats
tests.extend(validate_source_stats(C,ROOT))
science=[s for p in P for s in p['sources'] if s['ifu_science_pointing'] and not s.get('group_members') and '背景' not in s['role']]
out={'checked':'2026-10-04','cutoff':'2026-10-03','software_data_pass':all(t['pass'] for t in tests),'tests':tests,'scientific_gaps':{'science_pointings':len(science),'z_known':sum(s['z'] is not None for s in science),'z_range':sum(s['z_range'] is not None for s in science),'z_unknown':sum(s['z'] is None and s['z_range'] is None for s in science),'core_papers':len(C['core_papers']),'note':'范围仅是计划样本范围；指向数不等于独立星系数。未知源信息明确保留，不因缺数据处理结果降级。'}}
(D/'validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
if not out['software_data_pass']:raise SystemExit(1)
