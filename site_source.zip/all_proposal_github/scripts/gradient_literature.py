"""从人工原文摘录生成A类文献统计；标准库、离线，保留原计划条件，统一规范源映射。"""
from pathlib import Path
import collections,copy,csv,gzip,hashlib,html,json,re
KEYS=['programs','stats','audit','core_papers']
def read_catalog(root):
 p=Path(root)/'data/catalog.json'
 return json.loads(p.read_text() if p.exists() else gzip.decompress(p.with_suffix('.json.gz').read_bytes()).decode())
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def csvwrite(d,name,rows):
 if not rows:return
 with (d/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for r in rows for k in r)));w.writeheader()
  w.writerows({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()} for r in rows)
def build(programs,source_stats,d):
 d=Path(d);raw=json.loads((d/'a_gradient_literature.json').read_text());entries={e['id']:e for e in source_stats['entries']};reviews={r['source_id']:r for r in raw['sources']}
 if set(entries)!=set(reviews):raise ValueError('每个A源/群体必须有且只有一条文献状态记录')
 if len(reviews)!=len(raw['sources']):raise ValueError('重复源ID')
 papers={p['id']:p for p in raw['papers']}
 if len(papers)!=len(raw['papers']):raise ValueError('论文版本未合并')
 aliases={a:r['source_id'] for r in raw['merges'] for a in r['alias_source_ids']}
 if any(a in entries or b not in entries for a,b in aliases.items()):raise ValueError('同源别名须迁移到统一规范映射')
 a_pids={p['pid'] for p in programs if p['grade']=='A'};qualifying={(p['pid'],t['number']) for p in programs for t in p['sources'] if t['source_grade']=='A'}
 sources=[];groups=[];target_index=collections.defaultdict(list)
 for sid,e0 in entries.items():
  e=copy.deepcopy(e0);r=copy.deepcopy(reviews[sid]);ids=[sid]+e.get('alias_source_ids',[])
  r.update(id=sid,name=e['name'],redshift=e['redshift'],minimum=e['minimum'],lower_bound=e['lower_bound'],identity_evidence=e['identity_evidence'],aliases=e.get('aliases',[]),merged_source_ids=ids,members=e['members'])
  r['pids']=sorted({m['pid'] for m in r['members']},key=int)
  if any((m['pid'],m['target']) not in qualifying for m in r['members']):raise ValueError('B/背景源混入A统计')
  for field in ['search_records','survey_records','bibliography_pids']:
   r[field]=list(dict.fromkeys(r.get(field,[])))
  r['merge_evidence']=[x for x in raw['merges'] if x['source_id']==sid]
  if r['status'] not in raw['states']:raise ValueError('未知状态')
  for s in r['studies']:
   if s['paper_id'] not in papers or not s['locator'] or not s['evidence_url']:raise ValueError('论文证据不完整')
   if not set(s['data_pids']).issubset(set(papers[s['paper_id']]['data_pids'])):raise ValueError('源用PID超出论文用PID')
   if s['kind'] in ['radial','spatial'] and not papers[s['paper_id']]['full_text_status'].startswith('readable'):raise ValueError('正面成果缺少原文')
  kinds={s['kind'] for s in r['studies']};expected='radial' if 'radial' in kinds else 'spatial' if 'spatial' in kinds else r['status']
  if expected!=r['status']:raise ValueError('状态与原文成果冲突：'+sid)
  dest=groups if e['lower_bound'] or e['minimum']!=1 else sources
  r['scope']='group' if dest is groups else 'individual';dest.append(r)
  for m in r['members']:target_index[m['pid']+':'+m['target']].append(sid)
 for g0 in raw['groups']:
  g=copy.deepcopy(g0);g.update(scope='field',pids=sorted({m['pid'] for m in g['members']},key=int),minimum=None,lower_bound=True,studies=g.get('studies',[]),aliases=g.get('aliases',[]),merged_source_ids=g.get('merged_source_ids',[]),merge_evidence=[],identity_evidence=[])
  original=source_stats['pending'][int(g['id'].split(':')[-1])];g['identity_evidence']=[original.get('evidence',{})];g['redshift']=original.get('redshift');g['members']=original['members']
  if g['name'].startswith('BR1202') and not g.get('studies'):g['studies']=[{'paper_id':'2412.02751','kind':'other','result':'Table7给LAE及C1–C4分量丰度；成员的逐源A资格尚未对应，不折算为A源成果。','locator':'Table7；Sect.7.2','data_pids':['1220'],'component':'额外LAE及伴源，非已登记SMG','limits':'各成员身份/资格未逐项对应；不统计成员数量。','checked':raw['checked'],'evidence_url':'https://arxiv.org/html/2412.02751'}]
  groups.append(g)
  for m in g['members']:target_index[m['pid']+':'+m['target']].append(g['id'])
 proposals=[]
 for p in programs:
  if p['pid'] not in a_pids:continue
  ss=[s for s in sources if p['pid'] in s['pids']];gg=[g for g in groups if p['pid'] in g['pids']];counts={k:sum(s['status']==k for s in ss) for k in raw['states']}
  state=next((k for k in ['radial','spatial','not_found'] if counts[k]),'not_found')
  has_radial=counts['radial']>0;has_spatial=any(any(st['kind']=='spatial' for st in s['studies']) for s in ss)
  used={st['paper_id'] for s in ss for st in s['studies'] if p['pid'] in st['data_pids']}
  used_radial={st['paper_id'] for s in ss for st in s['studies'] if st['kind']=='radial' and p['pid'] in st['data_pids']}
  proposals.append({'pid':p['pid'],'title':p['title'],'status':state,'counts':counts,'source_ids':[s['id'] for s in ss],'group_ids':[g['id'] for g in gg],'has_radial':has_radial,'has_spatial':has_spatial,'used_paper_ids':sorted(used),'radial_data_paper_ids':sorted(used_radial),'checked':raw['checked']})
 stats={'individual_total':len(sources),'source_counts':{k:sum(s['status']==k for s in sources) for k in raw['states']},'proposal_total':len(proposals),'proposal_counts':{k:sum(p['status']==k for p in proposals) for k in raw['states']},'radial_proposals':sum(p['has_radial'] for p in proposals),'radial_data_proposals':sum(bool(p['radial_data_paper_ids']) for p in proposals),'papers':len(papers),'radial_papers':len({st['paper_id'] for s in sources for st in s['studies'] if st['kind']=='radial'}),'group_entries':len(groups),'group_member_lower_bound':sum(g['minimum'] or 0 for g in groups),'minimum_with_group_members':source_stats['minimum'],'new_alias_merges':len(aliases)}
 out={k:copy.deepcopy(raw[k]) for k in ['cutoff','checked','proposal_cutoff','states','criteria','source_count_note','merges','search_log','access_gaps']};out.update(stats=stats,sources=sources,groups=groups,proposals=proposals,papers=list(papers.values()),target_index=dict(target_index))
 (d/'a_gradient_statistics.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
 csvwrite(d,'a_gradient_sources.csv',[{'source_id':s['id'],'统计范围':s['scope'],'源':s['name'],'状态':raw['states'][s['status']],'关联PID':s['pids'],'下限':s.get('minimum'),'状态说明':s['reason'],'红移':s.get('redshift',{}),'指向':s['members'],'同源合并证据':s['merge_evidence'],'研究总览':s.get('summary',s['reason']),'逐论文成果':s['studies'],'检索记录':s.get('search_records',[]),'核查日期':raw['checked']} for s in sources+groups])
 csvwrite(d,'a_gradient_proposals.csv',[{'PID':p['pid'],'标题':p['title'],'汇总状态':raw['states'][p['status']],'逐源三类计数':p['counts'],'至少一个A源有径向成果':p['has_radial'],'论文实际使用本PID的径向成果':p['radial_data_paper_ids'],'关联源ID':p['source_ids'],'群体ID':p['group_ids'],'核查日期':p['checked']} for p in proposals])
 csvwrite(d,'a_gradient_papers.csv',list(papers.values()))
 csvwrite(d,'a_gradient_search_log.csv',out['search_log'])
 return out

def enrich(c,root):
 order_file=Path(root)/'data/gradient_audit_order_snapshot.json'
 if order_file.exists():
  order=json.loads(order_file.read_text())
  for row in c['audit']:
   prior=order.get(row['pid'],[]);row['discovery_sources']=sorted(row['discovery_sources'],key=lambda x:(prior.index(x) if x in prior else len(prior),x))
 c['a_gradient_literature']=build(c['programs'],c['source_statistics'],Path(root)/'data');return c

def update_documents(root):
 root=Path(root);index=root/'index.html'
 for f in root.glob('*.html'):
  s=f.read_text()
  if 'src="app.js"' in s and 'src="gradients.js"' not in s:s=s.replace('</head>','<script src="gradients.js" defer></script></head>')
  if '<nav aria-label="主导航">' in s and 'href="a_gradients.html"' not in s.split('</nav>',1)[0]:s=s.replace('<a href="criteria.html">','<a href="a_gradients.html">A 类文献</a><a href="criteria.html">',1)
  if f.name=='index.html' and 'id="gradientHome"' not in s:s=s.replace('<section class="catalog"','<section id="gradientHome" class="gradientHome" aria-label="A类金属梯度文献进展"></section>\n<section class="catalog"',1)
  s=re.sub(r'(src|href)="(styles\.css|(?:app|statistics|gradients)\.js|data/catalog\.js)(?:\?v=\d+)?"',lambda m:m.group(1)+'="'+m.group(2)+'?v=2026101203"',s)
  f.write_text(s)
 head=index.read_text().split('<main id="main">')[0]
 body='''<main id="main" class="reading gradientPage"><div class="eyebrow">A CLASS · GAS-PHASE METALLICITY · 文献截至 2026.10.12</div><h1>A 类源的金属梯度文献进展</h1><div id="gradientSummary"></div><form id="gradientFilters" class="filters" role="search"><label>视图<select id="gv"><option value="sources">去重科学目标</option><option value="proposals">Proposal</option></select></label><label>文献状态<select id="gs"><option value="">全部状态</option><option value="radial">已有径向金属梯度论文</option><option value="spatial">仅有二维／分量丰度论文</option><option value="not_found">未检索到空间气相丰度论文</option></select></label><label class="search">搜索源、PID或论文<input id="gq" type="search" placeholder="如 REBELS、Wolfe、3045、作者…"></label><label>关联 PID<input id="gp" type="text" inputmode="numeric" placeholder="全部 A 计划"></label><button type="reset">重置</button></form><p id="gradientCount" role="status" aria-live="polite"></p><div id="gradientResults"></div><section id="gradientGroups" class="panel"></section><section class="panel"><h2>三类文献状态的定义</h2><div id="gradientRules"></div></section></main><footer>文献与源统计修订2026-10-12 · 计划检索截至2026-10-03 · 评级修订2026-10-04</footer></body></html>'''
 (root/'a_gradients.html').write_text(re.sub(r'<title>.*?</title>','<title>A 类金属梯度文献 · Metallicity Gradient Research</title>',head)+body)
 stats=json.loads((root/'data/a_gradient_statistics.json').read_text())['stats'];sc=stats['source_counts']
 block=f'''\n<!-- A_GRADIENT_GUIDE -->
## A 类文献及统一源统计（2026-10-12）

{stats['proposal_total']}个A计划；{stats['individual_total']}个去重科学目标：{sc['radial']}径向、{sc['spatial']}仅二维／分量、{sc['not_found']}未检索到空间气相丰度。另有{stats['group_entries']}个群体／视场，CGG-z5至少6成员单列。前两类必须有对应本源的原文结果；整体、运动学、SED和未来研究不等于空间气相丰度。未检索到只代表截至检索日的公开检索结果。

`data/independent_sources.json`是研究目录、红移图与文献唯一的规范源映射。明确CRISTAL别名及拼接合并；10555四个位置作为一个身份解释未定的视场，不算四个独立A星系。源数由映射自动生成，不手填页面。数值、近似值、范围与冲突分开，不取中点或平均。原ABC分级、观测条件和计划检索日期保持不变；历史快照在完整版history/2026-10-12-before-three-literature-states及对应-github目录。

编辑`data/a_gradient_literature.json`：sources.source_id对应规范映射；studies.paper_id指向papers.id。结果必须给分量、诊断、测值/误差/单位、章节表图与限制；没有定量值时明确说明。data_pids为论文实际使用的数据计划，不能用该源所有关联PID代替。预印本与发表版共用一个论文ID。sources仅允许radial/spatial/not_found；groups不硬分配到独立目标统计。原文无法访问或身份对应不明的候选保留审计，不计已有成果。旧源ID放alias_source_ids或merged_source_ids，保持旧详情链接。

扩展介绍：sources[].summary写源级研究总览（约180–300字），studies[].summary写该论文对本源的研究（约200–400字）；summary_checked记录复读日期。特定目标方法与论文通用介绍不同，可在studies[].diagnostics、studies[].method写逐源覆盖；优先显示这些字段。先说明对象、方法，再写结果、意义与限制。原数值result、分类理由reason和出处locator均保留；summary缺失时沿用旧说明。界面和搜索读取同一文本，勿手填生成网页。data/paper_summary_review.json保存原文哈希、关联及引用／方法更正。

离线重建：

```sh
python scripts/build_catalog.py
python scripts/pages.py
python scripts/validate_gradients.py
python scripts/validate_paper_summaries.py
python scripts/validate.py
python scripts/package.py
```

数据导出继续生成`data/a_gradient_sources.csv`、`a_gradient_proposals.csv`、`a_gradient_papers.csv`和检索CSV，网页不列技术下载按钮。核查记录在gradient_report.html及data/gradient_validation.json；原检索响应、计划引用与复查记录在references/gradient_literature/review_2026-10-12。`scripts/retrieve_gradient_literature.py --export-queries`导出查询；`--refresh-bibliography`查官方书目；`--arxiv-search`查候选；`scripts/fetch_gradient_papers.py`保存原文（需requests/beautifulsoup4、PDF回退需pdftotext）。检索脚本不自动认定成果。书目可能滞后，不能把零篇当成没有相关论文。

本次扩写60个源／视场总览、121条逐篇介绍，覆盖29篇既有关联论文；未开展新检索。修改前完整版与GitHub版保存在完整版history/2026-10-12-before-expanded-paper-summaries及对应-github目录。扩写验收见paper_summary_report.html、data/paper_summary_validation.json及data/paper_summary_browser_validation.json。重建后可运行`python scripts/verify_three_state_rebuild.py`比较data/paper_summary_rebuild_baseline.json；旧data/three_state_rebuild_baseline.json保留。后续主动改变数据时另立新基准。旧保真基准保持，source_statistics变更由data/source_mapping_revision.json单独验收，其它科学字段逐项对比。浏览器验收在data/gradient_browser_validation.json；浏览器限制file://时仅记录静态检查，不冒充双击实测。网站未上传或发布。
<!-- /A_GRADIENT_GUIDE -->
'''
 for name in ['README.md','UPDATE_GUIDE.md']:
  p=root/name;s=p.read_text() if p.exists() else '# Metallicity Gradient Research\n';s=re.sub(r'\n<!-- A_GRADIENT_GUIDE -->.*?<!-- /A_GRADIENT_GUIDE -->\n','',s,flags=re.S);p.write_text(s+block)
 p=root/'REPOSITORY_README.md'
 if p.exists():
  repo=p.read_text();repo=repo.replace('独立源／proposal 两种视图，按径向、二维／分量、未检索到和待确认筛选，附论文链接、原文表图位置、实际用PID及CSV。','去重科学目标／proposal 两种视图，按径向、二维／分量、未检索到三类筛选，附论文链接、结果、原文表图位置及实际用PID。')
  repo=re.sub(r'\| A 类(?:源登记快照|去重科学目标).*?\|\n',f"| A 类去重科学目标 | {stats['individual_total']} 个 |\n",repo)
  ss=json.loads((root/'data/source_statistics.json').read_text());repo=re.sub(r'\| 有逐源数值红移的独立源.*?\|\n',f"| 有逐源数值红移的去重科学目标 | {ss['numeric_count']} 个 |\n",repo);repo=re.sub(r'\| 仅有范围或共同近似红移的源.*?\|\n',f"| 仅有范围或共同近似红移 | {ss['interval_minimum']-ss['group_member_lower_bound']}个目标＋群体至少{ss['group_member_lower_bound']}成员（单列） |\n",repo);repo=repo.replace('A 类文献截止：2026-10-11','A 类文献及源统计修订：2026-10-12')
  a=repo.index('## A 类金属梯度文献进展');b=repo.index('## 分级依据',a)
  repo=repo[:a]+f'''## A 类金属梯度文献进展

| 去重科学目标 | 数量 |
| --- | ---: |
| 已有径向金属梯度论文（含平坦结果） | {sc['radial']} |
| 仅有二维／分量丰度论文 | {sc['spatial']} |
| 未检索到空间气相丰度论文 | {sc['not_found']} |
| 合计 | {stats['individual_total']} |

{stats['proposal_total']}个A计划；{stats['radial_proposals']}个至少含一个有径向成果的A目标，其中{stats['radial_data_proposals']}个PID的数据实际用于径向论文。共{stats['papers']}篇去重关联论文，其中{stats['radial_papers']}篇提供径向结果。其它望远镜的气相梯度也计入，ALMA远红外GLAM模型与JWST光学O/H诊断分别说明。

另列{stats['group_entries']}个群体／视场：CGG-z5至少6成员，YD混合视场、BR1202额外成员和10555 LAE Cross不强行折算明确独立A目标数。研究目录、文献统计和红移图共用data/independent_sources.json；旧源数快照仅保存在本地历史资料。

径向类给出剖面、斜率或定量约束；二维／分量类有空间或速度分量丰度但无径向结果；未检索到只表示截至2026-10-12的公开检索结果，也可能有整体丰度、运动学等论文。原文无法访问或对应不明的候选保留审计，不计已有成果；不再形成第四类。

逐源总览串联相关研究；展开每篇论文先介绍对该源做了什么、结果及意义，再列诊断、误差单位与原文位置。可编辑summary字段保留，缺失时兼容旧说明。逐论文保留对应分量、诊断、结果及误差单位、原文表图和限制。编辑data/a_gradient_literature.json，重建步骤见UPDATE_GUIDE.md；源数与文献数字由数据生成。原ABC分级与观测配置保留。

'''+repo[b:];p.write_text(repo)
 p=root/'README.html'
 if p.exists():
  s=re.sub(r'<!-- A_GRADIENT_GUIDE -->.*?<!-- /A_GRADIENT_GUIDE -->','',p.read_text(),flags=re.S)
  s=s.replace('</main>','<!-- A_GRADIENT_GUIDE --><section><h2>A 类文献与统一源映射</h2><p><a href="a_gradients.html">去重科学目标／Proposal文献进展</a>。三类文献数量守恒，群体与多目标视场单列；研究目录和红移图使用同一映射。修改方法、审计数据及导出文件见UPDATE_GUIDE.md。</p></section><!-- /A_GRADIENT_GUIDE --></main>');p.write_text(s)

if __name__=='__main__':
 root=Path(__file__).resolve().parents[1];c=read_catalog(root)
 from source_statistics import build as source_build
 c['source_statistics']=source_build(c['programs'],root/'data');c=enrich(c,root)
 p=root/'data/catalog.json';raw=json.dumps(c,ensure_ascii=False,indent=2)
 if p.exists():p.write_text(raw)
 else:p.with_suffix('.json.gz').write_bytes(gzip.compress(raw.encode(),mtime=0))
 (root/'data/catalog.js').write_text('// 离线页面数据；请编辑原始JSON后重建。\nwindow.CATALOG='+json.dumps(c,ensure_ascii=False).replace('</','<\\/')+';\n')
 update_documents(root);print(json.dumps(c['a_gradient_literature']['stats'],ensure_ascii=False,indent=2))
