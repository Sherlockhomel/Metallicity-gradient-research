#!/usr/bin/env python3
"""可复现的官方资料采集。只下载计划/归档元数据，不下载科学 FITS。"""
import concurrent.futures, datetime, hashlib, json, re, time
from pathlib import Path
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parents[1]
REF=ROOT/'references'; DATA=ROOT/'data'
REF.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)
BASE='https://www.stsci.edu'

def save_json(name,value):
    (DATA/name).write_text(json.dumps(value,ensure_ascii=False,indent=2))

def fetch(url, name, method='GET', payload=None):
    path=REF/name
    if path.exists(): return path.read_bytes()
    err=''
    for attempt in range(3):
        try:
            r=requests.request(method,url,data=payload,timeout=(20,75),headers={'User-Agent':'ResearchMetadataAudit/1.0'})
            r.raise_for_status()
            path.write_bytes(r.content)
            event={'url':url,'file':name,'status':r.status_code,'bytes':len(r.content),'sha256':hashlib.sha256(r.content).hexdigest(),'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':method}
            if payload: event['request']=payload
            with (DATA/'retrieval_log.jsonl').open('a') as f:f.write(json.dumps(event,ensure_ascii=False)+'\n')
            return r.content
        except Exception as e:err=str(e);time.sleep(attempt+1)
    with (DATA/'retrieval_log.jsonl').open('a') as f:f.write(json.dumps({'url':url,'file':name,'error':err,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
    raise RuntimeError(err)

def inventories():
    u=BASE+'/jwst/science-execution/approved-programs'
    s=BeautifulSoup(fetch(u,'approved-programs.html'),'html.parser')
    links={urljoin(BASE,a['href']) for a in s.select('a[href]') if '/approved-programs/' in a['href'] and ('cycle-' in a['href'] or any(x in a['href'] for x in ['joint-observing','directors-discretionary','calibration','guaranteed-time','webb-first','/dd-ers/']))}
    def one(url):
        name=url.rstrip('/').split('/')[-1]+'.html'
        s=BeautifulSoup(fetch(url,name),'html.parser')
        rows=[]
        for table in s.select('table'):
            heads=[x.get_text(' ',strip=True) for x in table.select('tr')[0].select('th,td')]
            for tr in table.select('tr'):
                cells=[x.get_text(' ',strip=True) for x in tr.select('td')]
                if not cells:continue
                a=tr.select_one('a[href*="program="]')
                pid=re.search(r'program=(\d+)',a['href']).group(1) if a else (cells[0] if re.fullmatch(r'\d{3,5}',cells[0]) else None)
                if pid:rows.append({'pid':pid,'headers':heads,'cells':cells,'source':url,'local_source':'references/'+name,'table_context':table.find_previous(['h2','h3','h4']).get_text(' ',strip=True) if table.find_previous(['h2','h3','h4']) else ''})
        if not rows:
            for a in s.select('a[href*="program="]'):
                m=re.search(r'program=(\d+)',a['href'])
                if m:rows.append({'pid':m.group(1),'headers':[],'cells':[a.get_text(' ',strip=True)],'source':url,'local_source':'references/'+name,'table_context':''})
        print(name,len(rows),flush=True)
        return {'url':url,'rows':rows,'tables':len(s.select('table'))}
    out=[];errors=[]
    with concurrent.futures.ThreadPoolExecutor(5) as ex:
        fs={ex.submit(one,u):u for u in sorted(links)}
        for f in concurrent.futures.as_completed(fs):
            try:out.append(f.result())
            except Exception as e:errors.append({'url':fs[f],'error':str(e)})
    save_json('inventories.json',{'pages':out,'errors':errors,'cutoff':'2026-10-03'})
    print('unique PIDs',len({r['pid'] for p in out for r in p['rows']}),'errors',len(errors),flush=True)

def mast():
    # CAOM 查仪器子模式；分页直至官方报告的最后一页。
    outputs=[]
    for inst in ['NIRSPEC/IFU']:
        page=1
        while True:
            req={'service':'Mast.Caom.Filtered','params':{'columns':'*','filters':[{'paramName':'obs_collection','values':['JWST']},{'paramName':'instrument_name','values':[inst]}]},'format':'json','pagesize':10000,'page':page}
            name='mast_'+inst.replace('/','_')+'_'+str(page)+'.json'
            res=json.loads(fetch('https://mast.stsci.edu/api/v0/invoke',name,'POST',{'request':json.dumps(req)}))
            if res.get('status')!='COMPLETE':raise RuntimeError(str(res)[:1000])
            outputs.append({'instrument':inst,'page':page,'file':'references/'+name,'paging':res.get('paging'), 'count':len(res.get('data',[]))})
            print(name,len(res.get('data',[])),res.get('paging'),flush=True)
            paging=res.get('paging',{})
            if page>=paging.get('pagesFiltered',paging.get('pages',1)):break
            page+=1
    save_json('mast_pages.json',outputs)

if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('stage',choices=['inventory','mast']);o=a.parse_args()
    inventories() if o.stage=='inventory' else mast()
