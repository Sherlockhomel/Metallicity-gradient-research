"""导出检索条件并保存公共索引响应；结果只能用作候选，须人工读原文。
默认只导出条件，联网动作须显式参数。原2026-10-11响应不覆盖，新响应按UTC目录保存。
"""
from pathlib import Path
import argparse,datetime,hashlib,json,time,urllib.parse,re
ROOT=Path(__file__).resolve().parents[1]
def run():
 p=argparse.ArgumentParser();p.add_argument('--export-queries',action='store_true');p.add_argument('--refresh-bibliography',action='store_true');p.add_argument('--arxiv-search',action='store_true');p.add_argument('--limit',type=int,default=0);a=p.parse_args()
 data=json.loads((ROOT/'data/a_gradient_literature.json').read_text());queries=json.loads((ROOT/'references/gradient_literature/search_queries.json').read_text());stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');cache=ROOT/'references/gradient_literature/updates'/stamp;cache.mkdir(parents=True,exist_ok=True)
 (cache/'source_queries.json').write_text(json.dumps(queries,ensure_ascii=False,indent=2))
 # 保留原逐源检索条件；生成不依赖搜索服务的可重复arXiv查询表达式。
 current=[]
 for s in data['sources']:
  mapping=json.loads((ROOT/'data/independent_sources.json').read_text());entry=next(e for e in mapping['entries'] if e['id']==s['source_id']);names=[entry['name'],s['source_id'].split(':')[-1]]+entry.get('aliases',[])
  for q in queries:
   if s['source_id'] in q.get('source_ids',[]):names.extend(q.get('aliases',[]));names.extend(re.findall(r'"([^"]+)"',q.get('q','')))
  text=' OR '.join('all:"'+n.replace('"','')+'"' for n in dict.fromkeys(names))
  current.append({'source_id':s['source_id'],'arxiv_search_query':'('+text+') AND (all:metallicity OR all:gradient OR all:abundance)','web_query_records':[q for q in queries if s['source_id'] in q.get('source_ids',[])],'cutoff':data['cutoff']})
 (cache/'arxiv_queries.json').write_text(json.dumps(current,ensure_ascii=False,indent=2))
 if not (a.refresh_bibliography or a.arxiv_search):print('已导出查询条件：'+str(cache));return
 import requests
 logs=[]
 def request(name,url,params=None,payload=None):
  rec={'url':url,'params':params,'payload':payload,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'historical_cutoff':data['cutoff']}
  try:
   r=requests.post(url,json=payload,timeout=45) if payload else requests.get(url,params=params,timeout=45);rec['http_status']=r.status_code;r.raise_for_status();dest=cache/name;dest.write_bytes(r.content);rec.update(file=name,bytes=len(r.content),sha256=hashlib.sha256(r.content).hexdigest(),status='ok')
   if payload:
    rows=r.json();rec['count']=len(rows);rec['pagination']='pagesize1000；达到1000需检查额外页'
  except Exception as e:rec.update(status='access_gap',error=str(e))
  logs.append(rec);(cache/'requests.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2));time.sleep(3)
 if a.refresh_bibliography:
  pids=json.loads((ROOT/'references/gradient_literature/a_pids.json').read_text())
  for pid in pids[:a.limit or None]:request('bibliography_'+pid+'.json','https://archive.stsci.edu/papertrack/api/v0.1/public-search',payload={'mission':'JWST','jwst_programs':pid,'pagesize':1000})
 if a.arxiv_search:
  for i,q in enumerate(current[:a.limit or None]):
   # 日期限定首次公开；版本日期/发表状态仍需原文和出版社记录确认。
   condition=q['arxiv_search_query']+' AND submittedDate:[199101010000 TO '+data['cutoff'].replace('-','')+'2359]'
   request('arxiv_'+str(i)+'.xml','https://export.arxiv.org/api/query',params={'search_query':condition,'start':0,'max_results':100,'sortBy':'submittedDate','sortOrder':'descending'})
 print('响应和访问缺口：'+str(cache))
if __name__=='__main__':run()
