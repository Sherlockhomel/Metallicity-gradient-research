"""从可编辑映射生成独立A源统计；不修改proposal分级，不推断范围内部的分布。"""
import collections,csv,html,json,math
from pathlib import Path

CATEGORIES=['光谱红移','光度/计划估计','取得方式未说明']
COLORS=['#226659','#bb823e','#788996']

def redshift_category(kind):
    if any(k in kind for k in ['谱线','光谱','系统红移']):return CATEGORIES[0]
    if any(k in kind for k in ['光度','近似/选样','估计']):return CATEGORIES[1]
    return CATEGORIES[2]

def bin_index(z,width=1):
    """左闭右开；z=3进入[3,4)。"""
    return math.floor(z/width)

def choose_redshift(options):
    """已有逐源数值优于共同范围；冲突原样保留。"""
    numeric=[x for x in options if x['mode']=='numeric']
    values={x['value'] for x in numeric}
    if len(values)>1:return {'mode':'conflict','value':sorted(values),'evidence':numeric}
    if numeric:return min(numeric,key=lambda x:CATEGORIES.index(x['category']))
    vals={(x['mode'],json.dumps(x['value'])) for x in options}
    return options[0] if len(vals)==1 else {'mode':'conflict','value':[x['value'] for x in options],'evidence':options} if options else {'mode':'missing','value':None,'evidence':None}

def csvfile(path,rows):
    if not rows:return
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader()
        w.writerows({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in r.items()} for r in rows)

def build(programs,data_dir):
    root=data_dir.parent
    mapping=json.loads((data_dir/'independent_sources.json').read_text())
    targets={(p['pid'],s['number']):(p,s) for p in programs for s in p['sources']}
    candidates={k for k,(p,s) in targets.items() if s['source_grade']=='A'}
    used=set();entries=[]
    def member(m):
        key=(str(m['pid']),str(m['target']))
        if key not in candidates:raise ValueError(f'映射不对应A科学指向：{key}')
        p,s=targets[key]
        return {'pid':p['pid'],'target':s['number'],'target_name':s['name'],'configurations':s['setups'],'source_type':s['source_type'],'evidence':s['selection_evidence']}
    for g in mapping['entries']:
        keys={(str(m['pid']),str(m['target'])) for m in g['members']};used|=keys
        if not g['minimum'] or not g['identity_evidence']:raise ValueError('缺计数或身份出处：'+g['id'])
        r={**g,'members':[member(m) for m in g['members']]}
        options=[]
        for k in sorted(keys):
            p,s=targets[k];ze=s['z_evidence'] or {}
            if s['z'] is not None:options.append({'mode':'numeric','value':s['z'],'category':redshift_category(ze.get('kind','')),'evidence':ze,'pid':p['pid'],'target':s['number']})
            elif s['z_range']:
                lo,hi=s['z_range'];options.append({'mode':'approx' if lo==hi else 'range','value':lo if lo==hi else [lo,hi],'evidence':ze,'pid':p['pid'],'target':s['number']})
        if g.get('redshift'):z=g['redshift']
        else:z=choose_redshift(options)
        if z['mode']=='numeric' and (r['minimum']!=1 or r['lower_bound']):raise ValueError('群体不能冒充逐源数值红移：'+g['id'])
        r['redshift']=z;r['redshift_options']=options;entries.append(r)
    pending=[]
    for g in mapping['pending']:
        keys={(str(m['pid']),str(m['target'])) for m in g['members']};used|=keys
        pending.append({**g,'members':[member(m) for m in g['members']]})
    if used!=candidates:raise ValueError(f'A指向映射缺口：{candidates-used}；多余{used-candidates}')
    ids=[r['id'] for r in entries]
    if len(ids)!=len(set(ids)):raise ValueError('独立源ID重复')
    bins=[]
    numeric=[r for r in entries if r['redshift']['mode']=='numeric']
    upper=max([bin_index(r['redshift']['value']) for r in numeric]+[9])+1
    for i in range(2,upper):
        rs=[r for r in numeric if bin_index(r['redshift']['value'])==i]
        bins.append({'low':i,'high':i+1,'counts':{k:sum(r['redshift']['category']==k for r in rs) for k in CATEGORIES},'source_ids':[r['id'] for r in rs]})
    intervals=[];groups=collections.defaultdict(list)
    for r in entries:
        z=r['redshift']
        if z['mode'] in ['range','approx']:groups[(z['mode'],json.dumps(z['value']))].append(r)
    for (mode,val),rs in sorted(groups.items(),key=lambda item:float(json.loads(item[0][1])[0] if item[0][0]=='range' else json.loads(item[0][1]))):
        intervals.append({'mode':mode,'value':json.loads(val),'minimum':sum(r['minimum'] for r in rs),'lower_bound':any(r['lower_bound'] for r in rs),'source_ids':[r['id'] for r in rs]})
    result={'checked':'2026-10-04','cutoff':'2026-10-03','proposal_count':len(programs),'grades':dict(collections.Counter(p['grade'] for p in programs)),'a_pointings':len(candidates),'minimum':sum(r['minimum'] for r in entries),'lower_bound':bool(pending) or any(r['lower_bound'] for r in entries),'counted_records':len(entries),'numeric_count':len(numeric),'interval_minimum':sum(r['minimum'] for r in entries if r['redshift']['mode'] in ['range','approx']),'categories':CATEGORIES,'entries':entries,'pending':pending,'bins':bins,'intervals':intervals,'unplaced':[r['id'] for r in entries if r['redshift']['mode'] in ['missing','conflict']]}
    result['pointings']=[member({'pid':k[0],'target':k[1]}) for k in sorted(candidates,key=lambda k:(int(k[0]),int(k[1])))]
    (data_dir/'source_statistics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    csvfile(data_dir/'a_independent_sources.csv',[{'独立源ID':r['id'],'源名称':r['name'],'计数下限':r['minimum'],'数量为下限':r['lower_bound'],'PID_Target':r['members'],'红移类型':r['redshift']['mode'],'红移值或范围':r['redshift']['value'],'数值取得方式':r['redshift'].get('category',''),'红移出处':r['redshift']['evidence'],'身份出处':r['identity_evidence'],'计数说明':r['note']} for r in entries])
    csvfile(data_dir/'a_pointings.csv',[{'PID':k[0],'Target':k[1],'计划源名':targets[k][1]['name'],'配置':targets[k][1]['setups'],'来源':targets[k][1]['selection_evidence'],'对应独立源ID':[r['id'] for r in entries if any(m['pid']==k[0] and m['target']==k[1] for m in r['members'])],'待拆分':[g['name'] for g in pending if any(m['pid']==k[0] and m['target']==k[1] for m in g['members'])]} for k in sorted(candidates,key=lambda k:(int(k[0]),int(k[1])))])
    csvfile(data_dir/'a_pending_groups.csv',[{'群体':g['name'],'PID_Target':g['members'],'说明':g['note'],'出处':g['evidence']} for g in pending])
    csvfile(data_dir/'a_redshift_bins.csv',[{'左边界_含':b['low'],'右边界_不含':b['high'],**b['counts'],'独立源ID':b['source_ids']} for b in bins])
    csvfile(data_dir/'a_redshift_intervals.csv',[{'形式':g['mode'],'红移':g['value'],'源数下限':g['minimum'],'数量为下限':g['lower_bound'],'独立源ID':g['source_ids']} for g in intervals])
    charts=root/'charts';charts.mkdir(exist_ok=True)
    histogram(result,charts/'a_redshift_histogram.svg');interval_chart(result,charts/'a_redshift_intervals.svg')
    return result

def svg_start(title,desc,width,height):
    return [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-labelledby="title desc"><title id="title">{html.escape(title)}</title><desc id="desc">{html.escape(desc)}</desc><rect width="100%" height="100%" fill="#fff"/><g font-family="sans-serif" font-size="14" fill="#182b35">']

def histogram(s,path):
    w,h=900,350;left,top,bottom=60,28,292;bw=800/len(s['bins']);peak=max([sum(b['counts'].values()) for b in s['bins']]+[1]);peak=math.ceil(peak/5)*5
    out=svg_start('A类独立源逐源数值红移分布',f"{s['numeric_count']}个独立星系；Δz=1；范围和共同近似值另列。",w,h)
    for n in range(0,peak+1,5):
        y=bottom-n/peak*(bottom-top);out.append(f'<path d="M{left} {y}H860" stroke="#e0e7e2"/><text x="48" y="{y+5}" text-anchor="end">{n}</text>')
    for i,b in enumerate(s['bins']):
        x=left+i*bw+12;y=bottom;total=sum(b['counts'].values())
        for cat,color in zip(CATEGORIES,COLORS):
            n=b['counts'][cat];bh=n/peak*(bottom-top);y-=bh
            out.append(f'<rect x="{x}" y="{y}" width="{bw-24}" height="{bh}" fill="{color}"><title>[{b["low"]},{b["high"]}) · {cat}：{n}</title></rect>')
        out.append(f'<text x="{x+(bw-24)/2}" y="{y-7}" text-anchor="middle">{total}</text><text x="{x+(bw-24)/2}" y="318" text-anchor="middle">{b["low"]}–{b["high"]}</text>')
    out.append('<text x="450" y="342" text-anchor="middle">z（左闭右开）</text><text x="12" y="18">源数</text></g></svg>');path.write_text(''.join(out))

def interval_chart(s,path):
    w=900;h=65+36*len(s['intervals']);left,right=230,790;zmin,zmax=2,11
    out=svg_start('A类源计划红移范围及共同近似值','每行是一组计划范围或共同近似值，线长不代表概率分布。',w,h)
    pos=lambda z:left+(z-zmin)/(zmax-zmin)*(right-left)
    for z in range(zmin,zmax+1):
        x=pos(z);out.append(f'<path d="M{x} 20V{h-30}" stroke="#e0e7e2"/><text x="{x}" y="{h-8}" text-anchor="middle">{z}</text>')
    for i,g in enumerate(s['intervals']):
        y=36+i*36;v=g['value'];label=f'约 z {v}' if g['mode']=='approx' else f'z {v[0]}–{v[1]}'
        count=('≥' if g['lower_bound'] else '')+str(g['minimum'])+' 个'
        out.append(f'<text x="15" y="{y+5}">{label}</text><text x="815" y="{y+5}">{count}</text>')
        if g['mode']=='approx':out.append(f'<circle cx="{pos(v)}" cy="{y}" r="5" fill="#bb823e"/>')
        else:
            x1,x2=pos(v[0]),pos(v[1]);out.append(f'<path d="M{x1} {y}H{x2} M{x1} {y-6}V{y+6} M{x2} {y-6}V{y+6}" fill="none" stroke="#226659" stroke-width="3"/>')
    out.append('</g></svg>');path.write_text(''.join(out))
