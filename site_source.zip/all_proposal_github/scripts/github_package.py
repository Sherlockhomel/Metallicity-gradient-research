"""打包可直接上传的精简网站；ZIP为下载副本，排除自身及临时缓存。"""
from pathlib import Path
import hashlib,json,zipfile

def include(p,root):
    rel=p.relative_to(root)
    return p.is_file() and not p.is_symlink() and not any(x in rel.parts for x in ['.git','__pycache__']) and p.name not in ['.DS_Store','site_source.zip','github_package_validation.json'] and p.suffix not in ['.pyc','.tmp']

def package(root):
    root=Path(root);d=root/'downloads';d.mkdir(exist_ok=True);dest=d/'site_source.zip';tmp=dest.with_suffix('.tmp')
    files=[f for f in sorted(root.rglob('*')) if include(f,root)]
    inner={'checked':'2026-10-07','scope':'归档内部内容清单；ZIP本身的大小、CRC和SHA256见发布目录中的同名外部报告。','entries':len(files)+1,'payload_bytes':sum(f.stat().st_size for f in files),'file_sha256':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},'note':'归档不重复包含自身；解压后运行scripts/package.py可重新生成源码下载包。'}
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for f in files:z.write(f,'all_proposal_github/'+str(f.relative_to(root)))
        z.writestr('all_proposal_github/data/github_package_validation.json',json.dumps(inner,ensure_ascii=False,indent=2))
    tmp.replace(dest)
    with zipfile.ZipFile(dest) as z:
        bad=z.testzip()
        if bad:raise RuntimeError('ZIP CRC失败：'+bad)
    out={'checked':'2026-10-07','file':'downloads/site_source.zip','archive_root':'all_proposal_github','bytes':dest.stat().st_size,'payload_bytes':sum(f.stat().st_size for f in files),'folder_bytes':sum(f.stat().st_size for f in root.rglob('*') if f.is_file() and not any(x in f.parts for x in ['.git','__pycache__'])),'entries':len(files)+1,'largest_file':max(({'file':str(f.relative_to(root)),'bytes':f.stat().st_size} for f in files),key=lambda x:x['bytes']),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'crc':'PASS'}
    (root/'data/github_package_validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))

if __name__=='__main__':package(Path(__file__).resolve().parents[1])
