"""逐源扩写验收：文字覆盖、结果及来源、冻结统计、旧数据兼容及离线重建。"""
from pathlib import Path
import json,re,html,copy
from gradient_literature import read_catalog,digest,build
ROOT=Path(__file__).resolve().parents[1]
def validate(root=ROOT):
 root=Path(root);d=root/'data';c=read_catalog(root);l=c['a_gradient_literature'];raw=json.loads((d/'a_gradient_literature.json').read_text());b=json.loads((d/'paper_summary_preservation_baseline.json').read_text());tests=[]
 def check(name,ok,detail=''):tests.append({'test':name,'pass':bool(ok),'detail':detail})
 for k,v in b['signatures'].items():check('冻结科学数据与源统计：'+k,digest(c[k])==v)
 check('文献统计、类别、源成员与论文集合保持',l['stats']==b['literature_stats'] and {s['id']:s['status'] for s in l['sources']+l['groups']}==b['source_states'] and {s['id']:s['members'] for s in l['sources']+l['groups']}==b['members'] and {s['pid']:s['status'] for s in l['proposals']}==b['proposal_states'] and sorted(p['id'] for p in l['papers'])==b['paper_ids'])
 rows=[(s,st) for s in l['sources']+l['groups'] for st in s['studies']]
 covered=[s for s in l['sources']+l['groups'] if s['studies']]
 check('全部121条逐源论文与60个总览覆盖',len(rows)==121 and len(covered)==60 and all(st.get('summary') and s.get('summary') for s,st in rows))
 check('总览180–300字、逐篇200–400字',all(180<=len(s['summary'])<=300 for s in covered) and all(200<=len(st['summary'])<=400 for s,st in rows),{'source_min':min(len(s['summary']) for s in covered),'source_max':max(len(s['summary']) for s in covered),'study_min':min(len(st['summary']) for s,st in rows),'study_max':max(len(st['summary']) for s,st in rows)})
 check('摘要保留复读日期、原数值字段及原文位置',all(st['summary_checked']=='2026-10-12' and s['summary_checked']=='2026-10-12' and st['result'] and st['locator'] and st['evidence_url'].startswith('https:') for s,st in rows))
 review=json.loads((d/'paper_summary_review.json').read_text())
 check('29篇原文复读记录与本地全文齐全',len(review['papers'])==29 and all((root/p['file']).exists() for p in review['papers']))
 hz=next(s for s in l['sources'] if s['id']=='canonical:HZ10-COS-5.66-S');lee=next(st for st in hz['studies'] if st['paper_id']=='2603.13493');jones=next(st for st in hz['studies'] if st['paper_id']=='2405.12955')
 check('HZ10串联三种研究、E专属和平坦相容',all(n in hz['summary'] for n in ['Jones','Lee','外流','E','平坦','−0.019']) and all(n in lee['summary'] for n in ['已发表','丰度图','误差跨过零','指定对象／分量']) and all(n in jones['summary'] for n in ['0.52±0.09','0.63±0.10','0.71±0.12','没有把PRISM']))
 check('积分REBELS与空间ξion成果区分',all('积分' in st['summary'] and '12+log(O/H)' in st['summary'] and '不是' in st['summary'] for s,st in rows if st['paper_id']=='2501.10559') and all('ξion' in st['summary'] and '并不是O/H' in st['summary'] for s,st in rows if st['paper_id']=='2511.10743'))
 grb=next(s for s in l['sources'] if s['id']=='pid:2344:GRB150403A')
 check('GRB上限不冒充双侧测值或梯度',all(n in grb['studies'][0]['summary'] for n in ['Hβ','1σ','<8.79','并不意味着','没有宿主C的径向拟合']))
 check('ALPINE逐源差异保留、不同结果不平均',all(st['summary'].count(s['name'])>=1 and '误差' in st['summary'] for s,st in rows if st['paper_id'] in ['2510.16116','2603.13493'] and s['id'].split(':')[-1].startswith(('DC-','VC-'))))
 js=(root/'gradients.js').read_text()
 check('总览与逐篇摘要均展示、旧数据回退和文本转义',all(x in js for x in ['paragraphs(s.summary||s.reason)','paragraphs(s.summary)','h(t)','paperResearchSummary']))
 check('源与Proposal搜索覆盖新摘要','st.result,st.summary' in js and 's.reason,s.summary' in js and 't.summary' in js)
 check('保留三类，无新工具入口',set(l['states'])=={'radial','spatial','not_found'} and all(x not in js+(root/'a_gradients.html').read_text() for x in ['源 CSV','Proposal CSV','论文 CSV','逐源查询响应','身份、指向与检索出处']))
 check('离线文献重建完全一致',build(c['programs'],c['source_statistics'],d)==l)
 browser=json.loads((d/'paper_summary_browser_validation.json').read_text()) if (d/'paper_summary_browser_validation.json').exists() else {}
 out={'checked':'2026-10-12','passed':all(t['pass'] for t in tests),'source_overviews':len(covered),'source_paper_summaries':len(rows),'papers':29,'tests':tests,'browser_validation':browser,'corrections':review['corrections'],'note':'文字扩写为允许变化；programs、stats、source_statistics、audit、core_papers逐字段哈希及文献统计、状态、成员冻结。'}
 (d/'paper_summary_validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
 head=(root/'index.html').read_text().split('<main id="main">')[0];e=html.escape
 body=f'''<main id="main" class="reading"><h1>逐源论文总结扩写与验收</h1><p>2026-10-12重读已有原文，扩写{len(covered)}个源／视场总览、{len(rows)}条逐源论文总结，覆盖29篇现有关联论文。未检索新文献，等级、源数、三类文献状态与检索截止日均保留。</p><p>先介绍研究对象和方法，再说明结果、意义及限制。源卡片串联不同论文；展开后先读针对该源的介绍，再查诊断、数值和原文位置。summary为可编辑文本，缺失时兼容旧说明。</p><h2>原文复读与更正</h2><p><a href="data/paper_summary_review.json">原文哈希、章节及更正记录</a> · <a href="data/paper_summary_preservation_baseline.json">扩写前冻结基准</a></p><ul>{''.join('<li>'+e(x['source_id']+' / '+x['paper_id']+'：'+x['reason'])+'</li>' for x in review['corrections'])}</ul><h2>验收</h2><p>{'通过' if out['passed'] else '尚有失败'}：{len(tests)}项数据与构建检查；浏览器{'已完成本次检查' if browser.get('passed') else '本次检查未完成'}。<a href="data/paper_summary_validation.json">检查明细</a> · <a href="data/paper_summary_browser_validation.json">浏览器记录</a></p><table><thead><tr><th>检查</th><th>结果</th></tr></thead><tbody>{''.join('<tr><td>'+e(t['test'])+'</td><td>'+('通过' if t['pass'] else '失败')+'</td></tr>' for t in tests)}</tbody></table><p>本地file://双击仍因浏览器工具协议限制未实测，保留相对资源及无fetch的静态检查。源码ZIP单独检查CRC和归档关键文件哈希；本地交付，未上传或发布。</p></main><footer>2026-10-12 · 逐源论文介绍扩写</footer></body></html>'''
 (root/'paper_summary_report.html').write_text(re.sub(r'<title>.*?</title>','<title>逐源论文总结扩写验收</title>',head)+body)
 print(json.dumps({'passed':out['passed'],'checks':len(tests),'summaries':len(rows),'failed':[t for t in tests if not t['pass']]},ensure_ascii=False,indent=2));return out
if __name__=='__main__':
 if not validate()['passed']:raise SystemExit(1)
