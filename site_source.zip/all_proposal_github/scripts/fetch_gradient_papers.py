from pathlib import Path
import concurrent.futures,datetime,hashlib,json,re,requests,io
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1];stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');CACHE=ROOT/'references/gradient_literature/updates'/stamp/'papers';CACHE.mkdir(parents=True,exist_ok=True)
IDS={p['id'] for p in json.loads((ROOT/'data/a_gradient_literature.json').read_text())['papers']}
def one(aid):
 log=CACHE/f'{aid}.json'
 if log.exists():return
 record={'arxiv':aid,'checked':datetime.datetime.now(datetime.timezone.utc).date().isoformat(),'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requests':[]}
 def get(url,kind):
  r=requests.get(url,timeout=(10,35));record['requests'].append({'url':url,'status':r.status_code,'kind':kind,'sha256':hashlib.sha256(r.content).hexdigest()});r.raise_for_status();return r.content
 try:
  b=get('https://arxiv.org/abs/'+aid,'abstract');s=BeautifulSoup(b,'html.parser')
  def m(name):
   el=s.select_one('meta[name="'+name+'"]');return el.get('content','') if el else ''
  record.update(title=m('citation_title'),authors=[e['content'] for e in s.select('meta[name="citation_author"]')],date=m('citation_date'),doi=m('citation_doi'),journal=s.select_one('.jref').get_text(' ',strip=True) if s.select_one('.jref') else m('citation_journal_title'),publication_evidence=s.select_one('.tablecell.comments').get_text(' ',strip=True) if s.select_one('.tablecell.comments') else '',url='https://arxiv.org/abs/'+aid,abstract=s.select_one('blockquote.abstract').get_text(' ',strip=True) if s.select_one('blockquote.abstract') else '')
  record['versions']=[x.get_text(' ',strip=True) for x in s.select('.submission-history')]
  links=[x['href'] for x in s.select('a[href]') if '/html/' in x['href']];url=links[0] if links else 'https://arxiv.org/html/'+aid
  if url.startswith('/'):url='https://arxiv.org'+url
  try:
   h=BeautifulSoup(get(url,'full_html'),'html.parser');main=h.select_one('article') or h
   txt=main.get_text(' ',strip=True);(CACHE/f'{aid}.txt').write_text(txt)
   record.update(html_url=url,full_text_file=f'{aid}.txt',tables=[x.get_text(' ',strip=True) for x in main.select('table')],full_text_status='readable_html')
  except Exception as e:
   record['html_error']=str(e)
   try:
    import subprocess,tempfile
    pdf=get('https://arxiv.org/pdf/'+aid,'pdf')
    with tempfile.NamedTemporaryFile(suffix='.pdf') as tmp:
     tmp.write(pdf);tmp.flush();txt=subprocess.check_output(['pdftotext','-layout',tmp.name,'-']).decode()
    (CACHE/f'{aid}.txt').write_text(txt);record.update(pdf_url='https://arxiv.org/pdf/'+aid,full_text_file=f'{aid}.txt',full_text_status='readable_pdf')
   except Exception as pe:record.update(full_text_status='access_gap',pdf_error=str(pe))
 except Exception as e:record['abstract_error']=str(e)
 log.write_text(json.dumps(record,ensure_ascii=False,indent=2));print(aid,record.get('full_text_status','gap'),flush=True)
if __name__=='__main__':
 import sys
 if len(sys.argv)>1:IDS=set(sys.argv[1:])
 with concurrent.futures.ThreadPoolExecutor(3) as ex:list(ex.map(one,sorted(IDS)))
