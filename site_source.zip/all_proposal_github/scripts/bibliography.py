import sys,json,concurrent.futures,datetime,requests,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ids=json.loads((ROOT/'data/selection.json').read_text())['review_candidates']
url='https://archive.stsci.edu/papertrack/api/v0.1/public-search'
def one(pid):
 dest=ROOT/'references'/f'bibliography_{pid}.json'
 if dest.exists():return
 payload={'mission':'JWST','jwst_programs':pid,'pagesize':1000}
 try:
  r=requests.post(url,json=payload,timeout=(20,90));r.raise_for_status();d=r.json()
  if not isinstance(d,list):raise ValueError(str(d)[:300])
  dest.write_text(json.dumps(d,ensure_ascii=False,indent=2))
  with (ROOT/'data/retrieval_log.jsonl').open('a') as f:f.write(json.dumps({'url':url,'file':dest.name,'request':payload,'count':len(d),'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(r.content).hexdigest()})+'\n')
  print(pid,len(d),flush=True)
 except Exception as e:print(pid,'ERROR',str(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(2) as ex:list(ex.map(one,ids))
