import sys,json,concurrent.futures,xml.etree.ElementTree as ET
from pathlib import Path
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from retrieve import fetch,save_json
ids=json.loads((ROOT/'data/selection.json').read_text())['review_candidates']
def one(pid):
 d={'pid':pid,'errors':{},'visits':[]}
 for kind,url,name in [('status',f'https://www.stsci.edu/jwst-program-info/program/?program={pid}',f'status_{pid}.html'),('visits',f'https://www.stsci.edu/jwst-program-info/visits/?program={pid}&download=',f'visits_{pid}.xml'),('pdf',f'https://www.stsci.edu/jwst-program-info/download/jwst/pdf/{pid}/',f'proposal_{pid}.pdf')]:
  try:
   content=fetch(url,name)
   if kind=='status':
    s=BeautifulSoup(content,'html.parser');d['status_text']=s.get_text(' ',strip=True)
   if kind=='visits':
    root=ET.fromstring(content);d['report_time']=root.findtext('reportTime')
    d['visits']=[dict(v.attrib,**{x.tag:x.text for x in v if x.text}) for v in root.findall('visit')]
  except Exception as e:d['errors'][kind]=str(e)
 save_json(f'enrich_{pid}.json',d);print(pid,len(d['visits']),list(d['errors']),flush=True)
with concurrent.futures.ThreadPoolExecutor(5) as ex:list(ex.map(one,ids))
