"""独立验证文献命名空间。旧导出基准保留；允许新文献/显示标签，禁止改原科学字段。"""
from pathlib import Path
import collections,csv,html,json,re
from gradient_literature import read_catalog,digest,build,KEYS
ROOT=Path(__file__).resolve().parents[1]
def validate(root=ROOT):
 root=Path(root);c=read_catalog(root);l=c['a_gradient_literature'];d=root/'data';raw=json.loads((d/'a_gradient_literature.json').read_text());baseline=json.loads((d/'gradient_preservation_baseline.json').read_text());tests=[]
 def check(name,ok,detail=''):tests.append({'test':name,'pass':bool(ok),'detail':detail})
 for key in KEYS:check('修改前科学数据保留：'+key,digest(c[key])==baseline['signatures'][key])
 S={s['id']:s for s in l['sources']};P={p['id']:p for p in l['papers']};pro={p['pid']:p for p in l['proposals']}
 check('原125计划及31A等级保留',len(c['programs'])==125 and c['stats']['grades']=={'A':31,'B':71,'C':14,'未定级':9} and len(pro)==31)
 check('统一规范源与群体记录全部有三类状态',{r['source_id'] for r in raw['sources']}=={e['id'] for e in c['source_statistics']['entries']})
 check('去重科学目标三类互斥且守恒',len(S)==len(l['sources'])==sum(l['stats']['source_counts'].values()) and all(s['scope']=='individual' and s['minimum']==1 and not s['lower_bound'] for s in S.values()))
 check('状态计数来自逐源',l['stats']['source_counts']=={k:sum(s['status']==k for s in S.values()) for k in l['states']})
 check('全部A计划有汇总且三类守恒',set(pro)=={p['pid'] for p in c['programs'] if p['grade']=='A'} and sum(l['stats']['proposal_counts'].values())==31)
 check('Proposal至少一个径向与逐源一致',all(p['has_radial']==any(S[s]['status']=='radial' for s in p['source_ids']) and p['counts']=={k:sum(S[s]['status']==k for s in p['source_ids']) for k in l['states']} for p in pro.values()))
 check('每个正面成果可追溯原文、位置和日期',all(st['locator'] and st['evidence_url'].startswith('https:') and st['checked']==l['checked'] and P[st['paper_id']]['full_text_status'].startswith('readable') and (root/P[st['paper_id']]['full_text_file']).exists() for s in S.values() for st in s['studies'] if st['kind'] in ['radial','spatial']))
 check('论文版本去重，预印本与期刊共用ID',len(P)==len(l['papers']) and all(p['id']==p['arxiv'] for p in P.values()))
 check('只有A科学指向进入源统计',all(any(p['pid']==m['pid'] and any(t['number']==m['target'] and t['source_grade']=='A' for t in p['sources']) for p in c['programs']) for s in S.values() for m in s['members']))
 check('每个源有逐源检索/书目及检查日期',all(s.get('search_records') and s.get('bibliography_pids') and s['checked']==l['checked'] for s in S.values()))
 check('群体及三视场独立列出、不折算已做',len(l['groups'])==4 and l['stats']['group_member_lower_bound']==6 and all(g['status']=='not_found' and g['scope'] in ['group','field'] for g in l['groups']))
 check('三组CRISTAL/ALPINE合并有原文TableA1证据',len(l['merges'])==3 and all(x['locator'] and x['source'].endswith('2510.16111') for x in l['merges']) and all(len(S[x['source_id']]['merged_source_ids'])==2 for x in l['merges']))
 check('Wolfe盘跨PID只计一次且运动学不算梯度',S['canonical:DLA0817g1']['pids']==['4528','5761'] and S['canonical:DLA0817g1']['status']=='not_found' and all(st['kind']=='other' for st in S['canonical:DLA0817g1']['studies']))
 check('REBELS跨PID重复四组各只计一次',all(sum(s['name']==name for s in S.values())==1 for name in ['REBELS-05','REBELS-08','REBELS-29','REBELS-32']))
 check('REBELS25区域值与inprep不计径向',S['canonical:REBELS-25']['status']=='spatial' and any(st['paper_id']=='2608.25982' for st in S['canonical:REBELS-25']['studies']))
 check('8512拼接两对合并保留，8源完成复查',sum('8512' in s['pids'] for s in S.values())==8 and all(s['status']=='not_found' for s in S.values() if '8512' in s['pids']) and all(len(s['members'])==2 for s in S.values() if s['name'] in ['J0148-10916','J0100-09273']))
 check('混合1554只计西伴源，CEERS3/4分别计数',sum('1554' in s['pids'] for s in S.values())==1 and S['PJ308-21-west']['status']=='spatial' and len([s for s in S.values() if s['name'] in ['CEERS 3','CEERS 4','CEERS-3','CEERS-4']])==2)
 check('平坦梯度计径向；样本空斜率不冒充已做',S['canonical:BDF3299']['status']=='radial' and S['canonical:COSMOS24108']['status']=='radial' and S['canonical:DC-873756']['status']=='spatial')
 check('同源关联PID不误写为论文数据',pro['5974']['has_radial'] and not pro['5974']['radial_data_paper_ids'] and not pro['1840']['radial_data_paper_ids'] and all(set(st['data_pids'])<=set(P[st['paper_id']]['data_pids']) for s in S.values() for st in s['studies']))
 check('GRB更正已记录、源版本合并',P['2505.21643'].get('correction_note') and P['2505.21643']['correction_url'].endswith('staf1475'))
 generated=build(c['programs'],c['source_statistics'],d);check('离线文献重建内容一致',generated==l)
 js=(d/'catalog.js').read_text();loaded=json.loads(js.split('window.CATALOG=',1)[1].rsplit(';',1)[0].replace('<\\/','</'));check('离线catalog.js与JSON一致',loaded==c)
 missing=[]
 def paths(x):
  if isinstance(x,dict):
   for v in x.values():paths(v)
  elif isinstance(x,list):
   for v in x:paths(v)
  elif isinstance(x,str) and x.startswith(('references/','data/')) and not (root/x).is_file():missing.append(x)
 paths(l);check('所有本地原文、检索响应和资料链接存在',not missing,sorted(set(missing)))
 check('CSV源范围独立标记/31Proposal/论文完整',all((d/n).exists() for n in ['a_gradient_sources.csv','a_gradient_proposals.csv','a_gradient_papers.csv','a_gradient_search_log.csv']) and len(list(csv.DictReader((d/'a_gradient_proposals.csv').open(encoding='utf-8-sig'))))==31)
 check('旧导出基准/历史记录未覆盖',(d/'gradient_preservation_baseline.json').exists() and (not(root/'data/github_export_baseline.json').exists() or json.loads((d/'github_export_baseline.json').read_text())['checked']!='2026-10-11'))
 check('新页面、首页、详情和离线交互入口存在',(root/'a_gradients.html').exists() and 'id="gradientHome"' in (root/'index.html').read_text() and 'displayFlags' in (root/'app.js').read_text() and 'gradientProgress' in (root/'gradients.js').read_text() and 'popstate' in (root/'gradients.js').read_text())
 check('浏览层无需fetch',not re.search(r'\bfetch\s*\(', (root/'gradients.js').read_text()))
 fresh=json.loads((root/'references/gradient_literature/review_2026-10-12/requests.json').read_text());books=[x for x in fresh if 'bibliography_' in str(x.get('file',''))]
 check('31官方书目本次重新查询成功',len(books)==31 and all(x.get('status')==200 for x in books))
 check('三类状态不恢复第四类',set(l['states'])=={'radial','spatial','not_found'} and all(s['status'] in l['states'] for s in l['sources']+l['groups']))
 check('目录与文献源数及红移同源',c['source_statistics']['individual_total']==l['stats']['individual_total']==110 and {e['id'] for e in c['source_statistics']['entries'] if e['minimum']==1 and not e['lower_bound']}==set(S) and all(s['redshift']==next(e['redshift'] for e in c['source_statistics']['entries'] if e['id']==s['id']) for s in S.values()))
 check('10555四个旧ID均兼容到单列视场',not any('10555' in s['pids'] for s in S.values()) and any(g['id']=='field:2' and len(g['members'])==4 and len(g['merged_source_ids'])==4 for g in l['groups']))
 check('新增ALMA梯度源与论文归属正确',all(S[s]['status']=='radial' and any(st['paper_id']=='2309.07957' and not st['data_pids'] for st in S[s]['studies']) for s in ['canonical:COS-2987030247','canonical:COS30-COS-6.80-S','pid:4528:Z-001']))
 check('JADES和Z001红移有原文值',S['pid:4528:Z-001']['redshift']['value']==7.0611 and S['pid:4528:JADES-GS-53.087-27.86']['redshift']['value']==7.96)
 check('每项已有成果包含具体结果，径向含单位',all(st['result'] and re.search(r'\d',st['result']) and (st['kind']!='radial' or 'dex/kpc' in st['result']) for s in S.values() for st in s['studies'] if st['kind'] in ['radial','spatial']))
 check('旧pending链接兼容且界面无第四类',"q.get(k)==='pending'?" in (root/'gradients.js').read_text() and 'value="pending"' not in (root/'a_gradients.html').read_text() and '其次待确认' not in (root/'gradients.js').read_text())
 ui=(root/'a_gradients.html').read_text()+(root/'gradients.js').read_text()
 check('删除指定工具入口及技术出处块',all(x not in ui for x in ['源 CSV','Proposal CSV','论文 CSV','核查与验收','可编辑文献数据','身份、指向与检索出处','逐源查询响应','独立系统','四类源','原预计A源快照','sourceSnapshotNote']))
 check('三列文献卡与三类筛选','grid-template-columns:repeat(3,minmax(0,1fr))' in (root/'styles.css').read_text() and all(f'value="{k}"' in (root/'a_gradients.html').read_text() for k in l['states']))
 review=json.loads((root/'references/gradient_literature/review_2026-10-12/final_source_review.json').read_text())
 check('原21项复查记录保留并有最终归类',len(review['former_pending'])==21 and all(r['reviewed'] and r['final_status'] in l['states'] for r in review['former_pending']))
 b=json.loads((d/'gradient_browser_validation.json').read_text()) if (d/'gradient_browser_validation.json').exists() else {}
 out={'checked':l['checked'],'passed':all(t['pass'] for t in tests),'stats':l['stats'],'tests':tests,'browser_validation':b,'note':'原计划科学字段保留；规范源映射与文献为本次授权修订。浏览器结论只采用2026-10-12实际检查。'};(d/'gradient_validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
 head=(root/'index.html').read_text().split('<main id="main">')[0];e=html.escape
 text=f'''<main id="main" class="reading"><h1>A 类文献核查与验收</h1><p>文献复查2026-10-12；计划检索截至2026-10-03；评级修订2026-10-04。原计划分级、科学源条件及观测配置保留，源映射和红移统计按本次授权统一。<a href="a_gradients.html">文献进展清单</a></p><section><h2>结果与口径</h2><p>{l['stats']['proposal_total']}个A计划，{l['stats']['individual_total']}个去重科学目标，三类{e(str(l['stats']['source_counts']))}。另列{l['stats']['group_entries']}个群体／视场，CGG-z5至少6成员；10555不计四个独立星系。{l['stats']['radial_proposals']}个计划至少有一个A源径向成果，其中{l['stats']['radial_data_proposals']}个PID实际用于径向论文。{l['stats']['radial_papers']}篇径向论文包括ALMA远红外GLAM模型结果；与光学O/H方法分别说明。</p><p>原CRISTAL三组别名统一；Wolfe盘/REBELS重复观测、8512拼接、1554西伴星系及CEERS3/4保留原关联。旧源ID迁移记录见data/source_mapping_revision.json，旧快照只在history。平坦梯度计径向；DC873756空O/H斜率不算径向；LACES整体O/H与SED不算空间气相成果。</p></section><section><h2>复查记录与缺口</h2><p>31个PID官方书目重新查询，所有原A源与21项旧状态复查记录见references/gradient_literature/review_2026-10-12/final_source_review.json。引用计划名称、坐标、巡天与参考文献，读候选原文方法、样本表和结果；检索记录继续保存，不在研究页面显示技术链接。</p><ul>{''.join('<li>'+e(g['entry']+'：'+g['reason'])+'</li>' for g in l['access_gaps'])}</ul><p>未检索到只表示截至检索日没有找到可明确对应本目标的成果，不保证全球文献完备。无法访问或对应不明的候选不计已有成果，原因保留审计，不形成第四类。</p></section><section><h2>数据与构建验收</h2><p>{'通过' if out['passed'] else '尚有失败'}：{len(tests)}项。原programs、stats、audit、core_papers对比修改前哈希；source_statistics单独按规范映射验收。<a href="data/gradient_validation.json">记录</a></p><table><thead><tr><th>检查</th><th>结果</th></tr></thead><tbody>{''.join('<tr><td>'+e(t['test'])+'</td><td>'+('通过' if t['pass'] else '失败：'+e(str(t['detail'])))+'</td></tr>' for t in tests)}</tbody></table></section><section><h2>浏览器与压缩包</h2><p>{'本次实际浏览器检查通过。' if b.get('passed') and b.get('checked')=='2026-10-12' else '本次浏览器检查未完成。'}<a href="data/gradient_browser_validation.json">记录</a>。{e('；'.join(x['test']+'：'+x['reason'] for x in b.get('limitations',[])))} ZIP CRC、SHA256及逐文件核对见package_validation.json或github_package_validation.json。</p></section></main><footer>2026-10-12文献及源统计修订 · 本地交付，未发布</footer></body></html>'''
 (root/'gradient_report.html').write_text(re.sub(r'<title>.*?</title>','<title>A类文献核查与验收</title>',head)+text)
 print(json.dumps({'passed':out['passed'],'checks':len(tests),'failed':[t for t in tests if not t['pass']]},ensure_ascii=False,indent=2));return out
if __name__=='__main__':
 if not validate()['passed']:raise SystemExit(1)
