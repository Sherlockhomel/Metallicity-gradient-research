#!/usr/bin/env python3
"""从公开 APT、MAST 和人工复核表构建离线目录。不会下载科学数据。"""
import json,re,csv,collections,datetime,math,gzip
from proposal_selection import apply as apply_selection
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'data';R=ROOT/'references'
def read(p,default=None):
 if not p.exists() and p.with_suffix(p.suffix+'.gz').exists():p=p.with_suffix(p.suffix+'.gz')
 if not p.exists():return default
 return json.loads(gzip.open(p,'rt',encoding='utf-8').read() if p.suffix=='.gz' else p.read_text())
def norm(s):
 s=re.sub(r'^(NIRSPEC)','',re.sub(r'[^A-Z0-9]','',s.upper()))
 s=re.sub(r'(NIRSPECIFU|NIRSPEC|NIRSP|IFU)(OFFSET)?$','',s)
 return s
def coord(s):
 try:
  x=list(map(float,re.findall(r'[+-]?\d+(?:\.\d+)?',s)));return [(x[0]+x[1]/60+x[2]/3600)*15,(-1 if '-' in s else 1)*(abs(x[3])+x[4]/60+x[5]/3600)] if len(x)==6 else None
 except:return None
def evidence(value,url,locator,status='官方资料核实'):
 return dict(value=value,source=url,locator=locator,status=status,checked='2026-10-03')
def archive_files(pattern):
 order=read(D/'github_archive_order.json',[]);priority={name.removesuffix('.gz'):i for i,name in enumerate(order)}
 return sorted(R.glob(pattern+'*'),key=lambda f:priority.get(str(f.relative_to(ROOT)).removesuffix('.gz'),99999))
inst=read(D/'instrument.json');inst['lines_source']=read(D/'lines.json')['source'];reg=read(D/'source_registry.json',[])
programs={p['pid']:p for f in D.glob('program_*.json') if (p:=read(f))}
selection=read(D/'selection.json');review=set(selection['review_candidates']);excluded=set(selection['manual_exclusions'])
profiles=read(D/'proposal_selection.json')['programs']
legacy={p['pid']:p for p in read(D/'legacy.json')};inventory=read(D/'candidate_inventory.json')
cutoff=(datetime.datetime(2026,10,4)-datetime.datetime(1858,11,17)).total_seconds()/86400
caom=collections.defaultdict(list);mast=collections.defaultdict(dict);conflicts=[];mast_raw=0
legacy_mast=set()
for f in archive_files('mast_legacy_NIRSPEC_*.json'):
 for row in read(f,{}).get('data',[]):legacy_mast.add(str(row['proposal_id']).lstrip('0'))
for f in archive_files('mast_NIRSPEC_IFU_*.json'):
 for row in read(f,{}).get('data',[]):caom[str(row['proposal_id']).lstrip('0')].append(row)
for f in archive_files('mast_NRS_IFU_*.json'):
 for row in read(f,{}).get('data',[]):
  mast_raw+=1;pid=str(row.get('program','')).lstrip('0');fn=row.get('filename','');m=re.match(r'(jw\d{11}_\d{5}_\d{5})_nrs[12]_',fn)
  if not m or not row.get('expstart') or float(row['expstart'])>=cutoff:continue
  key=m.group(1);v=float(row.get('effexptm') or 0)
  if key in mast[pid]:
   if abs(mast[pid][key]['seconds']-v)>.1:conflicts.append({'pid':pid,'exposure':key,'values':[mast[pid][key]['seconds'],v]})
   continue
  mast[pid][key]={'exposure':key,'number':str(int(row['observtn'])),'visit':row.get('visit_id'),'target':row.get('targname'),'grating':row.get('grating'),'filter':row.get('filter'),'seconds':v,'date':(datetime.datetime(1858,11,17)+datetime.timedelta(days=float(row['expstart']))).isoformat(),'filename':fn,'metadata_file':str(f.relative_to(ROOT))}
def coverage(z,setups,z_range=None):
 if z is None and not z_range:return []
 a,b=(z,z) if z is not None else z_range
 out=[]
 for line in read(D/'lines.json')['lines']:
  name,rest=line['name'],line['rest_um'];lo,hi=rest*(1+a),rest*(1+b);options=[]
  for setup in setups:
   limits=inst['ranges'].get(setup)
   if not limits or hi<limits[0] or lo>limits[1]:continue
   full=limits[0]<=lo and hi<=limits[1];g=setup.split('/')[0];gi={'G140H':1,'G235H':3,'G395H':5}.get(g)
   lost=sum(lo<=row[gi+1] and hi>=row[gi] for row in inst['gaps']) if gi and setup!='G140H/F070LP' else 0
   label=('名义覆盖' if full else '只覆盖该红移范围的一部分')
   if lost:label+=f'；{lost}/30切片存在'+('间隙风险' if a==b else '区间与间隙重合')
   options.append({'setup':setup,'missing_slices':lost,'full_range':full,'label':label})
  out.append({'line':name,'rest_um':rest,'wavelength_um':round(lo,5) if z is not None else None,'wavelength_range_um':[round(lo,5),round(hi,5)] if z is None else None,'options':options})
 return out
manual_sources={'GS3073':(5.55,'2302.06647','Sect. 2'), 'COS3018':(6.85,'2411.07695','Sect. 2'), 'MACS1149JD1':(9.11,'2407.08616','Sect. 2'), 'EGSY8P7':(8.68,'APT1262','Abstract'), 'A2744YD4':(7.879,'2403.03977','Table 1'),'BDF3299':(7.114,'2403.03977','Table 1'),'COSMOS24108':(6.361,'2403.03977','Table 1'),'SGAS1723':(1.3293,'2401.13046','Abstract'),'SGAS1226':(2.925,'2401.13046','Abstract'),'SPT041847':(4.224,'2307.10412','Sect. 2'),'SPT214750':(3.76,'2307.10412','Sect. 2'),'SDSSJ1652':(2.94,'2210.10074','Sect. 2')}
for name,(z,src,loc) in manual_sources.items():reg.append(dict(canonical=name,aliases=[name],z=z,source='https://arxiv.org/abs/'+src if not src.startswith('APT') else programs['1262']['source'],locator=loc,status='原文核实',kind='原文红移',checked='2026-10-03'))
# 每篇核心论文只关联实际分析的数据，不将引言中的 PID 当成数据来源。
paper_specs={
 '2302.06647':(['1216'],'GS3073','整体 / AGN','光学强线、AGN 电离诊断；不可直接当成普通 H II 区径向梯度。','核区及窄线/宽线分解','低金属丰度 AGN 和大质量黑洞；提供电离来源对照。','Sect. 2–4'),
 '2411.07695':(['1217'],'COS-3018','二维分布 / 分量','Te（Main/North）；Curti2020 O32、R23、Ne3O2；N2用于整体。','逐 spaxel 及 Main/North/East 分量；不预先做 PSF 匹配或空间分箱','合并系统化学结构明显；二维方向变化不能直接等同统一径向梯度。','Sect. 2、4.2–4.4；Fig. 3'),
 '2407.08616':(['1262'],'MACS1149-JD1','二维分布','Te 与强线化学分析；需使用原文列出的线集合。','多分量及空间图','z=9.11 合并体系；NIRSpec 无 Hα，仍可用蓝端氧线分析。','Sect. 2、4'),
 '2501.10559':(['1626','2659'],'REBELS；2659仅COSMOS-978062/REBELS-18，坐标关联核实','整体丰度','Sanders2024 R3/R23，比较其他校准；四源 Hα 在波段之外。','整体提取；不是径向分箱论文','12个样本整体化学演化；校准系统差异可达约0.6 dex。','Sect. 2–4；Tables 1、3、5–8'),
 '2507.02053':(['1840'],'RIOJA 星系样本','整体 / 空间结构','Te/强线；详细逐源方法以原文为准。','分量和整体；径向梯度不能仅由标题推断','多相气体和化学性质；用作配置与丰度基准，非整计划梯度结论。','Sect. 2–4'),
 '2507.02054':(['1840'],'A1703-zD1','二维分布','[OIII]4363/5008 Te；[OII]双线 ne；联合 ALMA[OIII]88µm。','空间分辨 ISM，整体 Table 1','z=6.81、整体 12+log(O/H)=7.67(+0.11/−0.13)；不均匀密度/温度会影响丰度。','Table 1；Sect. 3–4'),
 '2403.03977':(['1893'],'A2744-YD4、BDF-3299、COSMOS24108','径向梯度','Curti 系列强线校准，R̂、R3、O32、Ne3O2；线 S/N>3 时使用。','0.05″圆环，以每个主要空间分量为中心；PSF 平滑后拟合','z~6–8 金属梯度；多个分量、透镜和 PSF 需分别处理。','Tables 1–2；Sect. 3.2–4'),
 '2604.07076':(['2957','2959'],'7个 z=7.21–9.51 星系（补充高分辨配置只适用相应源）','径向梯度','Isobe2026 R3 和 Ne3O2；S/N>3；R3单独使用时选择低丰度支。','0.05″圆环，以恒星连续谱峰为中心；MCMC 斜率','梯度多样性；R3支选择与 JADES10058975 AGN候选电离是关键限制。','Table 1；Sect. 3–4'),
 '2510.16111':(['3045','4265'],'ALPINE–CRISTAL 18个主序星系','样本 / 配置','光学谱线、运动学；不是仅靠目录即可认定的梯度论文。','IFU样本和减谱说明','Table 1提供红移/别名；18个指向数不等于后续20个梯度样本。','Table 1；Sect. 2–3'),
 '2510.16106':(['3045','4265'],'ALPINE–CRISTAL 主序星系','整体丰度','强线与部分源 Te；需逐源看温度线检测。','整体谱','快速化学富集；整体 MZR 不能替代空间梯度。','Table 1；Sect. 3–4'),
 '2603.13493':(['3045','4265','1217'],'CRISTAL20个星系/分量','径向梯度','联合多强线；主用 Sanders2025，并比较 Bian2018、Nakajima2022。','PSF统一到最红使用线；同心环；线 S/N≳2.5；线性斜率','中位斜率 +0.039±0.010 dex/kpc；无显著负梯度。样本补入4265与GA-NIFS，不能把全部20个记为3045。','Table 1–2；Sect. 2、4–6'),
 '2210.10074':(['1335'],'SDSS J1652+1728','电离 / 运动学','[OIII]多速度分量；QSO PSF分解。','多空间孔径','湍流和伴星系环境；用作AGN处理参照，未宣称径向丰度梯度。','Sect. 2–4'),
 '2307.10412':(['1355'],'SPT0418-47、SPT2147-50','二维分布','Hα/[NII] N2 强线经验校准；AGN区不适用普通SF校准。','空间分辨线图；透镜源平面','近太阳丰度及气尘比空间关系；SPT2147中局域AGN污染需屏蔽。','Sect. 2–4'),
 '2401.13046':(['1355'],'SGAS1723(z<2)、SGAS1226(z>2)','整体丰度 / 上限','[OIII]4363、[SIII]6312、[OII]7320/7330 Te。','整体积分谱','SGAS1723检测温度线；SGAS1226仅温度线上限，不能标为已测Te梯度。','Sect. 2–4'),
 '2405.06631':(['2555'],'Sunburst Arc LyC区','局部整体丰度','多电离区Te、ne；直接O/H、N/O和多元素。','同一LyC区5幅多重像叠加，不是5个独立星系','12+log(O/H)=7.97±0.05；N/O增强；测局部HII区而非径向梯度。','Sect. 2–4'),
 '2310.15967':(['2344'],'GRB宿主；IFU与固定狭缝混合','整体丰度','R̂、R23、R3等与吸收丰度比较。','整体宿主提取；不能把全部8源当IFU样本','多相丰度比较；空间分析需只选实际IFU观测。','Sect. 2–4；Table 1')}
paper_review_path=D/'paper_reviews.json'
if not paper_review_path.exists():paper_review_path.write_text(json.dumps({'说明':'核心论文人工方法复核：PID、源、层次、诊断、分箱、结果、章节；不得仅凭引言PID关联。','papers':paper_specs},ensure_ascii=False,indent=2))
paper_specs=read(paper_review_path)['papers']
core={}
for aid,spec in paper_specs.items():
 meta=read(D/f'paper_{aid}.json',{})
 if not meta:continue
 pids,src,kind,diag,bins,result,loc=spec
 core[aid]={k:meta.get(k) for k in ['arxiv','title','authors','date','journal','doi','url','html_url','publication_evidence','pdf_url','full_text_file']}
 core[aid].update(read(D/'publication_reviews.json',{}).get('papers',{}).get(aid,{}))
 core[aid].update(pids=pids,sources=src,kind=kind,diagnostics=diag,binning=bins,result=result,locator=loc,checked='2026-10-03',status=('全文已取得；方法复核尚不完整' if any(w in diag for w in ['以原文为准','需逐源','原文列出']) else '原文重点方法已复核') if (meta.get('html_available') or meta.get('full_text_available')) else '摘要复核；方法待全文核对')
reviews_path=D/'reviews.json'
reviews=read(reviews_path)['programs']
output=[]
for pid in sorted(review,key=int):
 p=programs.get(pid)
 if not p or not p['ifu_confirmed']:continue
 p=dict(p);unique={}
 for o in p['observations']:unique.setdefault(o['number'],o)
 p['duplicate_observation_nodes']=len(p['observations'])-len(unique);p['observations']=list(unique.values())
 p['grade']='未定级';p['scope']=profiles[pid]['scope'];p['notes']=''
 p['flags']=[]
 enrich=read(D/f'enrich_{pid}.json',{});p['visits']=[v for v in enrich.get('visits',[]) if 'NIRSpec IFU' in v.get('configuration','')]
 p['access_errors']=enrich.get('errors',{});p['exposure_records']=list(mast.get(pid,{}).values())
 rights=sorted({r.get('dataRights','UNKNOWN') for r in caom[pid]});p['data_rights']=rights
 for o in p['observations']:
  cr=[]
  for row in caom[pid]:
   oid=row.get('obs_id','');m=re.match(r'jw\d{5}(\d{3})\d{3}_',oid) or re.match(r'jw\d{5}-o(\d{3})_',oid)
   if m and int(m.group(1))==int(o['number']):cr.append(row)
  o['archive_rights']=sorted({x.get('dataRights','UNKNOWN') for x in cr})
  o['release_dates']=sorted({(datetime.datetime(1858,11,17)+datetime.timedelta(days=float(x['t_obs_release']))).strftime('%Y-%m-%d') for x in cr if x.get('t_obs_release') and float(x['t_obs_release'])>0})
 p['execution']='存在IFU归档元数据' if p['exposure_records'] else '尚无可计量的IFU归档曝光（不等于未执行）'
 p['official_status']=next((x for x in ['Completed','Executing','Implementation','Approved'] if x.lower() in enrich.get('status_text','').lower()),'查看官方状态/访问信息')
 p['sources']=[]
 for t in p['targets']:
  t=dict(t);name=t['name'];n=norm(name);point=t['ifu_science_pointing'];groups={g['number']:g.get('group_members',[]) for g in p['targets']}
  ob=[o for o in p['observations'] if o['target_number']==t['number'] or t['number'] in groups.get(o['target_number'],[])]
  role='科学指向' if point else '非IFU指向 / 定位或其它模式'
  if t.get('group_members'):role='目标组（科学和背景组合，非独立源）'
  if point and ('background target' in t['comments'].lower() or 'background pointing' in t['comments'].lower() or 'PSF' in name.upper() or t['category']=='Calibration' or re.search(r'(^|[-_])(SKY|BACKGROUND)([-_]|$)',name.upper())):role='背景 / PSF标定'
  if point and not t['category'] and not t.get('group_members'):role='IFU指向（科学/背景身份待核对）'
  setups=sorted({e['Grating'].upper()+'/'+e['Filter'].upper() for o in ob for e in o['exposures']})
  matches=[r for r in reg if (not r.get('pids') or pid in r['pids']) and any(norm(a)==n for a in r['aliases'])]
  # 少数明确名称带尾部NIRSpec，在上面归一化后完全匹配；不采用宽泛子串匹配。
  if not matches and pid=='2957':matches=[r for r in reg if any(norm(a).removeprefix('JADES')==n or norm(a).removeprefix('SMACS0723')==n for a in r['aliases'])]
  z=matches[0]['z'] if matches else None;ze=matches[0] if matches else None
  t.update(role=role,observations=[o['number'] for o in ob],setups=setups,z=z,z_evidence=ze,canonical=matches[0]['canonical'] if matches else name,aliases=matches[0]['aliases'] if matches else [],coverage=coverage(z,setups),coordinate_degrees=coord(t['coordinates']))
  t['evidence']=[evidence(name,p['source'],f'Targets / Target[{t["number"]}] / TargetName'),evidence(t['coordinates'],p['source'],f'Target[{t["number"]}] / EquatorialCoordinates'),evidence(setups,p['source'],'Observation / NirspecIFUSpectroscopy / Exposures'),ze or evidence('未知',p['source'],'公开APT未提供逐源红移','计划未给出')]
  p['sources'].append(t)
 p.pop('targets',None);p['papers']=[a for a in core.values() if pid in a['pids']]
 bib=read(R/f'bibliography_{pid}.json',None);p['bibliography']=bib or [];p['bibliography_status']='官方索引已查询；收录可能滞后' if bib is not None else '查询失败：缺口'
 p['checks']=[evidence(p['title'],p['source'],'ProposalInformation/Title'),evidence(p['pi'],p['source'],'PrincipalInvestigator'),evidence(p['cycle'],p['source'],'ProposalInformation/Cycle'),evidence(p['category'],p['source'],'ProposalInformation/ProposalCategory'),evidence(len(p['observations']),p['source'],'Observation/Template/NirspecIFUSpectroscopy'),evidence(len(p['exposure_records']),'https://mast.stsci.edu/portal/Mashup/Clients/Mast/Portal.html','Mast.Jwst.Filtered.Nirspec：exp_type=NRS_IFU，按exposure去重'),evidence(rights,'https://mast.stsci.edu/portal/Mashup/Clients/Mast/Portal.html','CAOM/dataRights（逐产品状态见原始元数据）'),evidence(p['grade'],p['source'],'本次科学适用性判断','分析判断，不是官方评级')]
 p['selection_evidence']=evidence(p['abstract'],p['source'],'ProposalInformation / Abstract；科学目标属于计划设计','计划书')
 apply_selection(p,profiles[pid],inst,{x['name']:x['rest_um'] for x in read(D/'lines.json')['lines']},coverage,evidence)
 p['checks'][-1]={**evidence(p['grade'],p['source'],'本网站按计划源类型与IFU配置筛选；非STScI官方评级','计划条件分类'),'checked':'2026-10-04'}
 output.append(p)
# 跨计划关联只用明确同一名称/论文别名；距离邻近另外提示，不自动合并。
same=collections.defaultdict(set)
for p in output:
 for t in p['sources']:
  if t['ifu_science_pointing'] and '背景' not in t['role']:same[norm(t['canonical'])].add(p['pid'])
for p in output:
 for t in p['sources']:
  t['related_pids']=sorted(same[norm(t['canonical'])]-{p['pid']},key=int)
  t['same_galaxy_targets']=[s['number'] for s in p['sources'] if s['ifu_science_pointing'] and '背景' not in s['role'] and s['number']!=t['number'] and norm(s['canonical'])==norm(t['canonical'])]
audit=[];universe=set(inventory['apt_candidates'])|set(inventory['all_official_rows'])|set(programs)|set(mast)|set(caom)
outids={p['pid'] for p in output}
for pid in sorted(universe,key=int):
 p=programs.get(pid,{});ifu=bool(p.get('ifu_confirmed') or mast.get(pid) or caom.get(pid));rows=inventory['all_official_rows'].get(pid,[])
 if pid in outids:disp=next(x['scope'] for x in output if x['pid']==pid);reason='公开IFU模板；高红移设计/源身份见详情'
 elif pid in legacy and not p:disp='待确认';reason='旧条目仅作线索；公开APT不可获取，不能确认IFU或科学身份'
 elif not p:disp='待确认';reason='公开APT获取/解析失败；仪器简表不足以证明非IFU'
 elif not ifu:disp='排除';reason='当前公开APT无NirspecIFUSpectroscopy，且未检出MAST IFU'
 elif p.get('category') in ['CAL','COM']:disp='排除';reason='校准或commissioning；非z>2科学样本'
 elif pid in excluded:disp='排除';reason=reviews.get(pid,{}).get('audit_reason','已审阅公开科学摘要：附近/低红移或恒星系统；不是z>2相关科学对象')
 elif any(w in (p.get('scientific_category','')+' '+p.get('title','')).lower() for w in ['solar system','stellar','exoplanet','protostar','planetary','planet formation','gas, dust','interstellar','debris','titan','uranus','neptune','asteroid','comet','pdr','hh211','kuiper','saturn','tno','ysos']):disp='排除';reason='公开APT科学类别与目标标题：太阳系/恒星/银河系气体；高红移例外已单独审阅并纳入'
 elif p.get('category')=='ENG':disp='排除';reason='公开工程观测，非高红移科学样本'
 else:disp='待确认';reason='IFU已确认；未完成逐源红移/目标身份判定，保留避免漏掉高红移对象'
 audit.append({'pid':pid,'title':p.get('title',''),'cycle':p.get('cycle',''),'category':p.get('category',''),'ifu':ifu,'apt_parsed':bool(p),'mast_products':len(caom.get(pid,[])),'unique_exposures':len(mast.get(pid,{})),'disposition':disp,'reason':reason,'source':p.get('source',''),'discovery_sources':list({x['source'] for x in rows})+(['MAST NRS_IFU'] if mast.get(pid) else [])+(['MAST NIRSPEC/IFU'] if caom.get(pid) else [])+(['MAST历史NIRSPEC（需APT判模式）'] if pid in legacy_mast else [])+(['原网站：仅线索'] if pid in legacy else [])})
def writecsv(name,rows):
 if not rows:return
 with (D/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v for k,v in row.items()} for row in rows)
writecsv('all_candidates.csv',audit);writecsv('all_ifu_proposals.csv',[a for a in audit if a['ifu']]);writecsv('exclusion_audit.csv',[a for a in audit if a['disposition']=='排除']);writecsv('pending_review.csv',[a for a in audit if a['disposition']=='待确认']);writecsv('actual_exposures.csv',[dict(pid=pid,**x) for pid,v in mast.items() for x in v.values()])
writecsv('sources.csv',[{'PID':p['pid'],'Target编号':t['number'],'源名称':t['name'],'角色':t['role'],'统一源':t['canonical'],'别名':t['aliases'],'J2000坐标':t['coordinates'],'源类型':t['source_type'],'源分级':t['source_grade'],'诊断路线':t['diagnostics'],'红移':t['z'],'计划红移范围':t['z_range'],'红移说明':t['redshift_note'],'红移来源':(t['z_evidence'] or {}).get('source','未知'),'红移位置':(t['z_evidence'] or {}).get('locator',''),'关联观测编号':t['observations'],'IFU配置':t['setups']} for p in output for t in p['sources']])
writecsv('planned_observations.csv',[{'PID':p['pid'],'观测编号':o['number'],'Target编号与名称':o['target_id'],'模式':o['mode'],'grating_filter_读出':o['exposures'],'Dither模式':o['dither'],'Dither位置':o['points'],'实际唯一曝光数':sum(e['number']==str(int(o['number'])) for e in p['exposure_records']),'实际EFFEXPTM秒':sum(e['seconds'] for e in p['exposure_records'] if e['number']==str(int(o['number']))),'归档权限':o['archive_rights'],'公开日期UTC':o['release_dates'],'当前APT来源':p['source']} for p in output for o in p['observations']])
corrections=[]
for pid,old in legacy.items():
 p=next((p for p in output if p['pid']==pid),None)
 corrections.append({'pid':pid,'action':'重新核实' if p else '移出已确认列表；待确认或排除','old_title':old['title'],'official_title':programs.get(pid,{}).get('title','待核实'),'old_grade':old['cls'],'new_grade':p['grade'] if p else next((a['disposition'] for a in audit if a['pid']==pid),'待确认'),'old_claim':old['sample']+'；z='+old['z'],'correction':p['grade_reason'] if p else reviews.get(pid,{}).get('audit_reason','以当前APT和排除审计为准。')})
for p in output:
 if p['pid'] not in legacy:corrections.append({'pid':p['pid'],'action':'新增','old_title':'','official_title':p['title'],'old_grade':'','new_grade':p['grade'],'old_claim':'','correction':'来自独立官方/MAST全量检索'})
for old in read(D/'legacy_exclusions.json',[]):
 pid=old['pid'];p=programs.get(pid,{})
 corrections.append({'pid':pid,'action':'复核旧版排除表','old_title':'旧排除条目','official_title':p.get('title','未取得'),'old_grade':'排除','new_grade':'排除/待确认见审计','old_claim':old['reason'],'correction':'当前APT模式：'+', '.join(p.get('all_modes',[]))+'；'+next((a['reason'] for a in audit if a['pid']==pid),'待确认')})
writecsv('corrections.csv',corrections)
stats={'classification_date':'2026-10-04','reviewed_programs':len(profiles),'cutoff':'2026-10-03','official_pages':len(read(D/'inventories.json')['pages']),'candidate_count':len(audit),'apt_parsed':sum(a['apt_parsed'] for a in audit),'ifu_count':sum(a['ifu'] for a in audit),'mast_products':mast_raw,'unique_exposures':sum(map(len,mast.values())),'site_count':len(output),'new_count':len(outids-set(legacy)),'scope':dict(collections.Counter(p['scope'] for p in output)),'grades':dict(collections.Counter(p['grade'] for p in output)),'dispositions':dict(collections.Counter(a['disposition'] for a in audit)),'ifu_dispositions':dict(collections.Counter(a['disposition'] for a in audit if a['ifu'])),'apt_missing':[a['pid'] for a in audit if not a['apt_parsed']],'exposure_conflicts':len(conflicts),'core_papers':len(core),'coverage_complete':False,'official_apt_coverage':sum(bool(programs.get(pid)) for pid in inventory['all_official_rows'])/len(inventory['all_official_rows'])}
from source_statistics import build as build_source_statistics
source_stats=build_source_statistics(output,D)
data={'source_statistics':source_stats,'stats':stats,'instrument':inst,'programs':output,'audit':audit,'core_papers':list(core.values())}
(D/'catalog.json').write_text(json.dumps(data,ensure_ascii=False,indent=2));(D/'catalog.js').write_text('// 离线数据。由 scripts/build_catalog.py 生成；请修改原始JSON再重建。\nwindow.CATALOG='+json.dumps(data,ensure_ascii=False).replace('</','<\\/')+';\n')
(D/'exposure_conflicts.json').write_text(json.dumps(conflicts,indent=2))
cycle_groups=collections.defaultdict(list)
for a in audit:cycle_groups[(a['cycle'],a['category'])].append(a)
writecsv('coverage_by_cycle_type.csv',[{'cycle':cy,'category':cat,'candidates':len(rs),'apt_parsed':sum(a['apt_parsed'] for a in rs),'ifu':sum(a['ifu'] for a in rs),'dispositions':dict(collections.Counter(a['disposition'] for a in rs))} for (cy,cat),rs in sorted(cycle_groups.items())])
old=None;oldp={}  # 既有126项目更正CSV已随发布副本保留；不重新构造已移出的历史资料。
writecsv('classification_revision.csv',[{'PID':pid,'旧等级':op['grade'],'新等级':next((p['grade'] for p in output if p['pid']==pid),'移至排除审计'),'新说明':next((p['grade_reason'] for p in output if p['pid']==pid),profiles.get(pid,{}).get('note','')),'依据':profiles.get(pid,{}).get('source',''),'位置':profiles.get(pid,{}).get('locator',''),'修订日期':'2026-10-04'} for pid,op in oldp.items()])
for p in output:reviews.setdefault(p['pid'],{}).update(grade=p['grade'],scope=p['scope'],grade_reason=p['grade_reason'],notes='',checked='2026-10-04',source=p['source'],locator='按proposal_selection.json源类型与当前IFU配置生成')
(D/'reviews.json').write_text(json.dumps({'说明':'现版等级由proposal_selection.json和当前IFU配置生成。本表保留审计和兼容输出，请在proposal_selection.json修改类型/范围/说明。','programs':reviews},ensure_ascii=False,indent=2))
print(json.dumps(stats,ensure_ascii=False,indent=2))

from github_publish_finalize import finalize
finalize(ROOT)
