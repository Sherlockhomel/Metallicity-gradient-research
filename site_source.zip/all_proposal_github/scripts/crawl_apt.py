#!/usr/bin/env python3
"""遍历官方批准清单全部计划，与MAST和旧线索取并集，读取全部观测模式模板；缓存支持断点续跑。"""
import sys,io,zipfile,json,re,concurrent.futures,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from retrieve import fetch,save_json
def tag(x):return x.tag.split('}')[-1]
def find(x,n):return next((e for e in x.iter() if tag(e)==n),None)
def text(x,n):
    e=find(x,n);return (e.text or '').strip() if e is not None else ''
def flat(x):return {tag(e):(e.text or '').strip() for e in x.iter() if not len(e) and e.text}
def parse(pid,content):
    z=zipfile.ZipFile(io.BytesIO(content));name=next(n for n in z.namelist() if n.endswith('.xml') and '/lib/' not in n)
    r=ET.fromstring(z.read(name));pi=find(r,'PrincipalInvestigator');info=find(r,'ProposalInformation')
    p={'pid':pid,'title':text(info,'Title'),'abstract':text(info,'Abstract'),'observing_description':text(info,'ObservingDescription'),'cycle':text(info,'Cycle'),'category':text(info,'ProposalCategory'),'scientific_category':text(info,'ScientificCategory'),'phase':text(info,'ProposalPhase'),'pi':' '.join(text(pi,n) for n in ['FirstName','MiddleInitial','LastName']).strip(),'allocated_hours':text(info,'AllocatedTime'),'proprietary':text(info,'ProprietaryPeriod'),'keywords':[e.text for e in info if tag(e)=='ScienceKeyword'],'targets':[],'observations':[],'all_modes':[],'source':'https://www.stsci.edu/jwst-program-info/download/jwst/apt/'+pid+'/','source_file':'references/apt_'+pid+'.aptx'}
    for t in r.iter():
        if tag(t)=='Target' and text(t,'Number'):
            eq=find(t,'EquatorialCoordinates');f=flat(t)
            p['targets'].append({'number':text(t,'Number'),'name':text(t,'TargetName'),'archive_name':text(t,'TargetArchiveName') or text(t,'TargetID'),'group_members':[(e.text or '').split(' ')[0] for e in t if tag(e)=='Target' and e.text],'target_type':t.attrib.get('{http://www.w3.org/2001/XMLSchema-instance}type',''),'coordinates':eq.attrib.get('Value','') if eq is not None else '', 'category':text(t,'Category'),'keywords':text(t,'Keywords'),'extended':text(t,'Extended'),'comments':text(t,'Comments'),'background_requested':text(t,'BackgroundTargetReq'),'redshift_apt':next((v for k,v in f.items() if 'redshift' in k.lower()),'')})
        if tag(t)=='Observation':
            template=find(t,'Template')
            if template is None or not len(template):continue
            mode=tag(template[0]);p['all_modes'].append(mode)
            if mode!='NirspecIFUSpectroscopy':continue
            te=template[0];oid=text(t,'Number');tid=text(t,'TargetID')
            exp=[]
            es=find(te,'Exposures')
            if es is not None:
                for e in es:
                    f=flat(e);exp.append({k:f.get(k,'') for k in ['Grating','Filter','ReadoutPattern','Groups','Integrations','Autocal','Leakcal','Dither']})
            status=[{tag(e):(e.text or '').strip(),**e.attrib} for e in t.iter() if tag(e) in ['VisitStatus','ObservationStatus','Status','ExecutionDate']]
            p['observations'].append({'number':oid,'label':text(t,'Label'),'target_id':tid,'target_number':tid.split(' ')[0],'mode':mode,'science_duration_s':text(t,'ScienceDuration'),'dither':text(te,'DitherType'),'dither_size':text(te,'DitherSize'),'points':text(te,'Points'),'ta_method':text(te,'TaMethod'),'acquisition_target':text(te,'AcqTargetID'),'comments':text(t,'Comments'),'background':text(te,'BackgroundTarget'),'exposures':exp,'status':status})
    p['all_modes']=sorted(set(p['all_modes']));p['ifu_confirmed']=bool(p['observations'])
    ids={o['target_number'] for o in p['observations']}
    groups={t['number']:t['group_members'] for t in p['targets'] if t['group_members']}
    for i in list(ids):ids.update(groups.get(i,[]))
    for t in p['targets']:t['ifu_science_pointing']=t['number'] in ids
    return p

def candidates():
    inv=json.loads((ROOT/'data/inventories.json').read_text());rows=[r for p in inv['pages'] for r in p['rows']]
    allrows={}
    for r in rows:allrows.setdefault(r['pid'],[]).append(r)
    selected=set(allrows)
    for r in rows:
        if 'nirspec' in ' '.join(r['cells']).lower() or any(x in r['source'] for x in ['calibration','joint-observing']):selected.add(r['pid'])
    for p in inv['pages']:
        m=re.search(r'/program-(\d+)$',p['url'])
        if m:selected.add(m.group(1));allrows.setdefault(m.group(1),[{'source':p['url'],'cells':[],'table_context':'ERS'}])
    selected.update(p['pid'] for p in json.loads((ROOT/'data/legacy.json').read_text()))
    if (ROOT/'data/legacy_exclusions.json').exists():selected.update(p['pid'] for p in json.loads((ROOT/'data/legacy_exclusions.json').read_text()))
    for f in (ROOT/'references').glob('mast_*.json'):
        try:d=json.loads(f.read_text())
        except:continue
        for r in d.get('data',[]):
            pid=str(r.get('proposal_id',r.get('program',''))).lstrip('0')
            if pid:selected.add(pid)
    save_json('candidate_inventory.json',{'all_official_rows':allrows,'apt_candidates':sorted(selected,key=int),'selection':'ALL official approved rows, ERS linked pages, MAST IFU and historical NIRSPEC union, previous website clues; all modes checked in APT.'})
    return sorted(selected,key=int)

if __name__=='__main__':
    ids=candidates();print('APT candidates',len(ids),flush=True)
    out={};errs={};done=0
    def one(pid):
        dest=ROOT/'data'/('program_'+pid+'.json')
        if dest.exists():return json.loads(dest.read_text())
        u='https://www.stsci.edu/jwst-program-info/download/jwst/apt/'+pid+'/'
        p=parse(pid,fetch(u,'apt_'+pid+'.aptx'));dest.write_text(json.dumps(p,ensure_ascii=False,indent=2));return p
    with concurrent.futures.ThreadPoolExecutor(6) as ex:
        fs={ex.submit(one,p):p for p in ids}
        for f in concurrent.futures.as_completed(fs):
            pid=fs[f];done+=1
            try:out[pid]=f.result()
            except Exception as e:errs[pid]=str(e)
            if done%25==0:print('APT',done,'/',len(ids),'IFU',sum(x['ifu_confirmed'] for x in out.values()),'errors',len(errs),flush=True)
    save_json('apt_audit.json',{'total_candidates':len(ids),'parsed':len(out),'ifu_count':sum(x['ifu_confirmed'] for x in out.values()),'errors':errs})
    print('DONE',len(out),'IFU',sum(x['ifu_confirmed'] for x in out.values()),'errors',errs,flush=True)
