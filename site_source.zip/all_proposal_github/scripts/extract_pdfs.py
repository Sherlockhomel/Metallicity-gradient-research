"""公开proposal PDF文字提取，记录失败；不是科学数据处理。"""
import json
from pathlib import Path
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1]
results=[]
for f in (ROOT/'references').glob('proposal_*.pdf'):
 try:
  text='\n\n'.join(p.extract_text() or '' for p in PdfReader(f).pages)
  f.with_suffix('.txt').write_text(text)
  results.append({'file':f.name,'characters':len(text),'status':'提取成功'})
 except Exception as e:results.append({'file':f.name,'status':'失败','error':str(e)})
(ROOT/'data/pdf_extraction.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print(len(results),'PDFs')
