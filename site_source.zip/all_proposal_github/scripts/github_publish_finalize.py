"""GitHub发布副本的链接与说明；科研内容、检索截止日与分级日期不变。"""
from pathlib import Path
import json,re,html,hashlib,gzip

DATE='2026-10-07'
EDITABLE={'proposal_selection.json','source_registry.json','independent_sources.json','paper_reviews.json','publication_reviews.json','selection.json','instrument.json','lines.json'}

def public_url(value):
    if value=='data/catalog.json':return 'data/catalog.json.gz'
    m=re.fullmatch(r'references/apt_(\d+)\.aptx',value)
    if m:return f'https://www.stsci.edu/jwst-program-info/download/jwst/apt/{m[1]}/'
    m=re.fullmatch(r'references/proposal_(\d+)\.pdf',value)
    if m:return f'https://www.stsci.edu/jwst-program-info/download/jwst/pdf/{m[1]}/'
    if re.fullmatch(r'references/mast_.*\.json',value):return value+'.gz'
    return value

def normalize(value):
    if isinstance(value,dict):return {k:normalize(v) for k,v in value.items()}
    if isinstance(value,list):return [normalize(v) for v in value]
    if isinstance(value,str):return public_url(value)
    return value

def canonical(value):
    """用于导出保真比对：URL规范化，忽略列表显示顺序，保留所有字段和值。"""
    value=normalize(value)
    if isinstance(value,dict):return {k:canonical(v) for k,v in sorted(value.items())}
    if isinstance(value,list):return sorted([canonical(v) for v in value],key=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True))
    return value

def signature(value):return hashlib.sha256(json.dumps(canonical(value),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def read_catalog(root):
    p=Path(root)/'data/catalog.json'
    return json.loads(p.read_text() if p.exists() else gzip.open(p.with_suffix('.json.gz'),'rt',encoding='utf-8').read())

def write_catalog(root,c):
    c=normalize(c)
    text=json.dumps(c,ensure_ascii=False,separators=(',',':'))
    with (root/'data/catalog.json.gz').open('wb') as fd:
        with gzip.GzipFile(filename='',mode='wb',fileobj=fd,compresslevel=9,mtime=0) as g:g.write(text.encode())
    if (root/'data/catalog.json').exists():(root/'data/catalog.json').unlink()
    (root/'data/catalog.js').write_text('// 离线页面数据；由scripts/build_catalog.py生成。\nwindow.CATALOG='+text.replace('</','<\\/')+';\n',encoding='utf-8')
    return c

def finalize(root):
    root=Path(root)
    for p in (root/'data').glob('*.json'):
        if p.name in {'references_manifest.json','github_export_manifest.json','github_archive_order.json'}:continue # 原版缓存清单是历史记录，不伪造它的原始路径/哈希。
        value=normalize(json.loads(p.read_text()))
        p.write_text(json.dumps(value,ensure_ascii=False,indent=2) if p.name in EDITABLE else json.dumps(value,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    c=write_catalog(root,read_catalog(root))
    for p in root.glob('*.html'):
        s=p.read_text().replace('href="jwst_ifu_site_source.zip"','href="downloads/site_source.zip"').replace('完整网站与源码ZIP','GitHub精简版源码ZIP').replace('href="data/catalog.json"','href="data/catalog.json.gz"')
        s=s.replace('原始资料在references；旧页面、分类数据和审计清单保留在history/2026-10-03。','本发布版保留无损压缩的MAST元数据与论文文本；原始APT/PDF及历史版本留在本地完整版all_proposal。')
        p.write_text(s,encoding='utf-8')
    head=(root/'index.html').read_text().split('<main id="main">')[0]
    title='GitHub发布版 · 源码与修改'
    body='''<h1>GitHub发布版 · 源码与修改</h1>
<p>保留研究目录、125个详情、源与观测、论文、独立A源统计、全量审计和下载数据。浏览无需安装；双击index.html也可使用。科研快照截至2026-10-03，分级修订2026-10-04；本副本于2026-10-07整理。</p>
<section><h2>大小如何缩减</h2><p>APT与proposal PDF使用STScI官方入口；原始文件和历史版本保留在本地完整版all_proposal。MAST原始响应和可下载页面JSON保留为.json.gz，解压内容完整。浏览使用正常的catalog.js，无需解压或额外安装。论文文本及关联书目仍保留；观测、曝光、红移、诊断与论文内容保留。</p></section>
<section><h2>修改入口</h2><p>外观styles.css；首页index.html；目录与详情app.js；统计statistics.js。源类型、计划红移和说明修改<a href="data/proposal_selection.json">人工分类数据</a>；逐源红移及别名修改<a href="data/source_registry.json">源登记表</a>；去重与成员下限修改<a href="data/independent_sources.json">独立源映射</a>。核心论文介绍修改data/paper_reviews.json、data/publication_reviews.json。</p><p>scripts/build_catalog.py使用本副本的解析JSON与压缩MAST缓存重建，无需原始APT或网络；scripts/pages.py生成分类与审计页；scripts/github_publish_finalize.py维护本页及发布说明。请按<a href="UPDATE_GUIDE.md">修改指南</a>重建，使重建结果继续使用官方APT/PDF入口。</p></section>
<section><h2>发布与下载</h2><p><a href="GITHUB_GUIDE.md">GitHub上传与Pages设置</a> · <a href="downloads/site_source.zip">精简版网站与源码ZIP</a> · <a href="data/catalog.json.gz">页面JSON（gzip下载）</a> · <a href="data/a_independent_sources.csv">独立A源CSV</a> · <a href="github_report.html">本次精简与验收报告</a> · <a href="verification_report.html">原科研整理报告</a></p><p>上传解压后的文件内容，使index.html位于仓库根目录。ZIP是下载副本；GitHub Pages直接使用网页文件。原完整版的大ZIP和历史备份留在本地。</p></section>'''
    (root/'README.html').write_text(re.sub(r'<title>.*?</title>','<title>'+title+'</title>',head)+'<main id="main" class="reading">'+body+'</main><footer>GitHub发布副本2026-10-07 · 科研快照2026-10-03</footer></body></html>',encoding='utf-8')
    (root/'GITHUB_GUIDE.md').write_text('''# GitHub Pages上传说明

本目录是独立可浏览、可重建的精简发布副本。科研快照截至2026-10-03，分级修订2026-10-04；整理日期2026-10-07。原all_proposal完整资料保留，没有上传或发布。

1. 创建一个Public仓库，例如metallicity-gradient-research。
2. 用GitHub Desktop提交本目录内容，或在GitHub网页Add file → Upload files上传。index.html必须位于仓库根目录，data、charts、references、scripts、downloads保持同级结构。首次提交较多文件时，GitHub Desktop更方便；网页上传可按文件夹分批进行。
3. 保留空的.nojekyll文件；不要上传符号链接、Python缓存、原版APT/PDF和history。
4. Settings → Pages → Source选择Deploy from a branch，Branch选main，Folder选/(root)，Save。
5. 发布完成后点击Visit site。网址通常为https://你的用户名.github.io/metallicity-gradient-research/。
6. 验证等级卡、搜索、任一详情、红移图、审计和CSV下载；项目子路径下也应正常工作。

downloads/site_source.zip是本发布版的源码下载副本，可以一并上传以支持网站的下载入口。ZIP不直接作为Pages入口。完整版的大ZIP留在本地，若需要公开分发可另上传GitHub Releases并修改相关下载入口。

所有文件的实际大小、CRC和SHA256见data/github_package_validation.json；功能与链接检查见github_report.html。Github设置帮助：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
''',encoding='utf-8')
    (root/'UPDATE_GUIDE.md').write_text('''# GitHub精简版修改与更新

浏览无需安装；重建使用Python 3.10或更新版本，已有缓存重建只依赖标准库。外部官方资料链接需要网络。本副本维护科研快照2026-10-03和分级日期2026-10-04；导出日期2026-10-07不表示重新检索。

## 修改数据

- 外观styles.css，首页index.html，目录与详情app.js，统计statistics.js。
- 分类、源类型、共同红移范围与项目说明：data/proposal_selection.json。
- 已测逐源红移、规范名和别名：data/source_registry.json。共同范围不应编造成逐源精确红移。
- 独立A源合并、拆分与群体下限：data/independent_sources.json。
- 论文方法、结果与出处：data/paper_reviews.json；发表信息：data/publication_reviews.json。
- 分类与审计页由scripts/pages.py生成；本源码说明页由scripts/github_publish_finalize.py生成。

## 在本目录离线重建

```
python scripts/build_catalog.py
python scripts/pages.py
python scripts/report.py
python scripts/validate.py
python scripts/validate_github.py
python scripts/report.py
python scripts/package.py
```

build_catalog.py可直接读取references/*.json.gz，按data/github_archive_order.json保留原快照的读取顺序，确保重复产品去重选择、曝光时间和日期一致；无需下载科学FITS或原始APT。每次构建后自动规范APT/PDF官方链接、MAST压缩缓存链接，并生成正常catalog.js用于浏览，完整页面JSON保存为data/catalog.json.gz用于下载，保持双击可用。

不要只修改生成的catalog.json或catalog.js，否则下次重建会覆盖。修改人工数据后必须运行构建脚本。新增源或主动修订科研结论时，应同步更新科研验收基准；data/github_export_baseline.json记录本次精简前的科研快照，用于本次无损导出检查，不是将来的新研究结论。

scripts/report.py保留原科研整理报告；scripts/validate_github.py检查发布版链接、压缩缓存和文件尺寸并生成github_report.html；data/github_browser_validation.json只记录实际执行过的浏览器检查，重建不自动证明浏览器检查通过。package.py最后生成downloads/site_source.zip并校验CRC。

## 从完整版再次导出

```
python scripts/export_github.py --source ../all_proposal --output ../all_proposal_github_new
```

输出目录必须是新目录，防止覆盖用户后续修改；导出不修改源目录。原APT/PDF和历史版本仍在完整版。完整检索脚本源码保留在scripts中，但重新检索会产生大量原始缓存，不应在发布目录中运行；如需新快照，先在新的完整版目录执行检索，复核后再导出。
''',encoding='utf-8')
    (root/'README.md').write_text('# Metallicity Gradient Research\n\n静态JWST NIRSpec IFU金属丰度研究目录。125个计划详情、A/B/C/未定级统计、独立A源及红移图、论文与检索审计。\n\n双击[index.html](index.html)即可本地查看；也可按[GitHub Pages上传说明](GITHUB_GUIDE.md)发布。上传本目录内的文件，让index.html位于仓库根目录；首次上传建议使用GitHub Desktop，避免逐批处理大量文件。\n\nAPT/PDF采用官方链接，MAST元数据无损压缩。可编辑数据及Python构建脚本保留，见[修改指南](UPDATE_GUIDE.md)。[精简验收报告](github_report.html)与[网站及源码ZIP](downloads/site_source.zip)附于本目录。\n\n检索快照2026-10-03；评级修订2026-10-04；本次精简2026-10-07。原始完整版all_proposal保留，没有上传或发布网站。\n',encoding='utf-8')
    return c

if __name__=='__main__':finalize(Path(__file__).resolve().parents[1])
