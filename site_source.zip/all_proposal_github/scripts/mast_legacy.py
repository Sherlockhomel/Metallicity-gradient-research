"""历史NIRSPEC仪器字符串补查。所有候选仍需APT辨别模式。"""
import json
from retrieve import fetch,save_json
out=[];page=1
while True:
 q={'service':'Mast.Caom.Filtered','params':{'columns':'proposal_id,instrument_name,obs_id,target_name','filters':[{'paramName':'obs_collection','values':['JWST']},{'paramName':'instrument_name','values':['NIRSPEC']}]},'format':'json','pagesize':10000,'page':page}
 name=f'mast_legacy_NIRSPEC_{page}.json';d=json.loads(fetch('https://mast.stsci.edu/api/v0/invoke',name,'POST',{'request':json.dumps(q)}))
 if d.get('status')!='COMPLETE':raise RuntimeError(str(d)[:500])
 out.append({'file':'references/'+name,'page':page,'count':len(d['data']),'paging':d['paging']})
 if page>=d['paging']['pagesFiltered']:break
 page+=1
save_json('mast_legacy_pages.json',out)
