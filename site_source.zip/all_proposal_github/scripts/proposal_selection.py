"""按计划源类型、红移与IFU诊断覆盖筛选；不使用尺寸、PSF、S/N或源数门槛。"""
import collections

DIAGNOSTICS={
 'R3':['Hbeta','OIII5007'],
 'R23':['OII3726','Hbeta','OIII5007'],
 'Ne3O2':['OII3726','NeIII3869'],
 'N2':['Halpha','NII6583'],
 'O3N2':['Hbeta','OIII5007','Halpha','NII6583'],
 'Te氧线路线':['Hbeta','OIII4363','OIII5007'],
}
TYPES={'SFG':'星形成星系','AGN':'AGN / 类星体宿主','透镜SFG':'强透镜星形成星系','透镜AGN':'强透镜AGN / 类星体','静止星系':'静止星系 / 恒星性质研究','静止候选':'透镜静止候选','电离来源混合':'星形成 / AGN或其它电离来源混合','前景恒星动力学':'前景透镜恒星动力学','超新星':'超新星喷射物光谱','身份未明':'对象身份尚未确定','混合SFG/AGN':'同一视场含星形成分量与AGN'}

def available(z,setups,inst,lines):
 """仅按名义波段判断设计。间隙不直接等同实际缺线；PRISM的N2/O3N2不成立。"""
 hits={}
 for name,names in DIAGNOSTICS.items():
  if all(any(inst['ranges'].get(s,[1,0])[0]<=lines[line]*(1+z)<=inst['ranges'].get(s,[1,0])[1]
             and (name not in ['N2','O3N2'] or not s.startswith('PRISM')) for s in setups) for line in names):hits[name]=names
 return list(hits)

def apply(p,profile,inst,lines,coverage,evidence):
 sources=p['sources'];grades=[]
 for t in sources:
  n=t['number'];ov=profile.get('sources',{}).get(n,{})
  typ=ov.get('source_type',profile['source_type']);ev={**evidence('',ov.get('source',profile['source']),ov.get('locator',profile['locator']),'计划书'), 'checked':'2026-10-04'}
  t.pop('suitability',None);t.pop('source_assessment',None)
  if ov.get('canonical'):t['canonical']=ov['canonical']
  if ov.get('aliases'):t['aliases']=sorted(set(t['aliases']+ov['aliases']))
  is_science=t['ifu_science_pointing'] and not t.get('group_members') and '背景' not in t['role']
  if is_science and any(x in t['name'].upper() for x in ['BACKGROUND','-BKG','_BKG','BACKGR','-SKY','_SKY']):
   t['role']='背景 / PSF标定';is_science=False
  if is_science and t['role'].startswith('IFU指向'):t['role']='科学指向（按计划观测说明）'
  t['source_type']=TYPES.get(typ,typ) if is_science else ('背景 / 标定目标' if '背景' in t['role'] else '其它模式 / 定位目标；APT类型：'+(t['category'] or '未给出')+(' · '+t['keywords'] if t.get('keywords') else ''));t['type_evidence']=ev if is_science else {**ev,'locator':f'Targets / Target[{n}] / Category、Keywords；Observation / TargetID'}
  znew=ov.get('z');zr=ov.get('z_range');default=profile.get('redshift')
  if znew is not None and (t['z'] is None or ov.get('force_z')):
   t['z']=znew;t['z_evidence']={**ev,'value':znew,'kind':'计划明确列出的源红移（保留计划精度）'}
  if t['z'] is None and zr is None and is_science:
   if isinstance(default,list):zr=default
   elif default is not None:
    # 单对象或同一场景可显示计划近似值；多个对象只列共同计划近似值而不假装独立测量。
    science=[s for s in sources if s['ifu_science_pointing'] and not s.get('group_members') and '背景' not in s['role']]
    if len(science)==1:
     t['z']=default;t['z_evidence']={**ev,'value':default,'kind':'计划中的近似/选样红移，并非新测量'}
    else:zr=[default,default]
  t['z_range']=zr if t['z'] is None else None
  zev=ev if znew is not None or ov.get('z_range') else {**ev,'source':profile['source'],'locator':profile['locator']}
  t['redshift_note']=ov.get('redshift_note','')
  if t['z_range']:
   a,b=t['z_range'];t['z_label']=f'计划样本约{a}' if a==b else f'计划范围 {a}–{b}'
   t['z_evidence']={**zev,'value':t['z_label'],'kind':'计划样本范围；非该源独立红移测量'}
  else:t['z_label']=str(t['z']) if t['z'] is not None else profile.get('redshift_text','计划未给出数值')
  t['coverage']=coverage(t['z'],t['setups'],t['z_range'])
  t['evidence'][3]=t['z_evidence'] or {**ev,'value':'计划未列数值红移'}
  diag=[];every=False;some=False
  if t['z'] is not None:zs=[t['z']]
  elif t['z_range']:
   a,b=t['z_range'];zs=[a+(b-a)*i/20 for i in range(21)]
   # 同时检查每条谱线越过波段边界的两侧，避免区间采样漏掉狭窄空窗。
   for limits in inst['ranges'].values():
    for rest in lines.values():
     for edge in limits:
      zz=edge/rest-1
      if a<zz<b:zs.extend([max(a,zz-1e-7),min(b,zz+1e-7)])
  else:zs=[]
  if zs:
   ds=[available(z,t['setups'],inst,lines) for z in zs];diag=sorted({d for x in ds for d in x});every=all(ds);some=any(ds)
  intent=ov.get('diagnostic_intent',profile.get('diagnostic_intent',False))
  highz=t['z']>2 if t['z'] is not None else (t['z_range'][0]>=2 and t['z_range'][1]>2 if t['z_range'] else profile.get('highz_design',False))
  if not is_science:g='不参与分级';why='定位、其它模式、背景或目标组，不是独立IFU科学源。'
  elif t['z'] is not None and t['z']<=2:g='排除';why='源红移不满足本课题z>2范围。'
  elif typ in ['静止星系','前景恒星动力学','超新星']:
   g='C';why={'静止星系':'计划主要研究恒星吸收谱、恒星年龄/动力学或淬火；不能把恒星金属丰度当作普通HII区气相O/H。','前景恒星动力学':'IFU科学目标是前景透镜的恒星动力学；背景QSO红移不能作为前景源红移或HII气体证据。','超新星':'主要谱线来自超新星喷射物及其演化；不能按宿主HII区气相O/H解释。'}[typ]
  elif typ=='身份未明':g='未定级';why=profile['note']
  elif not highz:g='未定级';why='计划红移范围跨z=2，或未给出数值红移，不能确定严格z>2条件。'
  elif not zs and not intent:g='未定级';why='计划明确高z设计，但未给逐源数值或足够的诊断覆盖说明。'
  elif every or (intent and not zs):
   if not diag:diag=list(intent) if isinstance(intent,list) else ['计划明确设计的光学谱线诊断']
   g='A' if typ in ['SFG','混合SFG/AGN'] else 'B'
   varying=bool(zs and len({tuple(x) for x in ds})>1)
   why=('按实际红移可选' if varying else '配置支持')+ ' / '.join(diag)+('（不同红移段可用组合不同）' if varying else '')+'；'+('普通星形成源可作为气相丰度研究候选。' if g=='A' else '需'+('透镜源平面重建，并分离AGN电离。' if typ=='透镜AGN' else '透镜源平面重建。' if typ in ['透镜SFG','静止候选'] else '分离AGN或其它电离来源与HII区气体。'))
  elif some:g='未定级';why='计划红移范围内仅部分区间有可用诊断，需要该源的具体红移才能确定路线。'
  elif zs:
   g='C';missing=[l for l in ['OII3726','NeIII3869','Hbeta','OIII5007','Halpha','NII6583'] if not any(inst['ranges'].get(st,[1,0])[0]<=lines[l]*(1+zz)<=inst['ranges'].get(st,[1,0])[1] for st in t['setups'] for zz in zs)]
   why='当前IFU配置不提供本课题气相诊断组合；'+('名义波段外的关键线为'+ '、'.join(missing)+'。' if missing else '覆盖的线不足以形成可分辨的R3/R23、Ne3O2或N2/O3N2组合。')
  else:g='未定级';why='计划未列该源的数值红移或可关联的诊断路线。'
  t['source_grade']=g;t['diagnostics']=diag;t['selection_reason']=why
  t['selection_evidence']={**ev,'value':why,'status':'按计划条件筛选'}
  t['components']=ov.get('components',[])
  if t['components'] and g=='A':t['selection_reason']+='A级只针对所列星形成分量；AGN分量为B。'
  if is_science and ov.get('note'):t['selection_reason']+=ov['note']
  t['selection_evidence']['value']=t['selection_reason']
  t['type_evidence']['value']=t['source_type']
  if is_science:grades.append(g)
  if is_science and t['z'] is None and not t['z_range'] and profile['note']:t['redshift_note']=t['redshift_note'] or profile['note']
 p['grade']='A' if 'A' in grades else 'B' if 'B' in grades else '未定级' if '未定级' in grades or not grades else 'C'
 p['scope']=profile['scope'];p['classification_date']='2026-10-04';p['classification_basis']='计划源类型、红移与IFU配置；不要求数据处理结果'
 count=collections.Counter(grades);p['source_grade_counts']=dict(count)
 chosen=[s for s in sources if s['source_grade']==p['grade'] and s['ifu_science_pointing'] and not s.get('group_members')]
 if not chosen:chosen=[s for s in sources if s['ifu_science_pointing'] and not s.get('group_members') and '背景' not in s['role']]
 parts=[]
 for t in chosen[:2]:
  typ=t['source_type'];parts.append(f'{t["name"]}（{typ}，z {t["z_label"]}；{"、".join(t["setups"])}）：{t["selection_reason"]}')
 if len(chosen)>2:parts.append(f'另有{len(chosen)-2}个同等级IFU指向，逐源见详情')
 if p['grade']=='A' and count['B']:parts.append(f'项目同时有{count["B"]}个B类指向，A级不适用于这些AGN/透镜目标')
 if profile['note']:parts.append(profile['note'])
 p['grade_reason']=' '.join(parts);p['notes']='';p.pop('confidence',None)
 flags=profile.get('flags',[]).copy()
 if any('AGN' in t['source_type'] or '电离来源' in t['source_type'] for t in sources if t['ifu_science_pointing'] and '背景' not in t['role']):flags.append('AGN/电离来源')
 if any('透镜' in t['source_type'] for t in sources if t['ifu_science_pointing'] and '背景' not in t['role']):flags.append('强透镜')
 if 'A' in grades and 'B' in grades:flags.append('混合A/B源')
 p['flags']=list(dict.fromkeys(flags))
