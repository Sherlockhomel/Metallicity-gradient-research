import sys,json,re,concurrent.futures
from pathlib import Path
from bs4 import BeautifulSoup
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from retrieve import fetch,save_json
legacy=json.loads((ROOT/'data/legacy.json').read_text());ids={re.search(r'/abs/(.*)',a['u']).group(1) for p in legacy for a in p['papers']}
ids.add('2210.10074')
if (ROOT/'data/paper_reviews.json').exists():ids.update(json.loads((ROOT/'data/paper_reviews.json').read_text())['papers'])
def one(aid):
    s=BeautifulSoup(fetch('https://arxiv.org/abs/'+aid,'paper_'+aid+'_abs.html'),'html.parser')
    def m(name):
        el=s.select_one('meta[name="'+name+'"]');return el.get('content','') if el else ''
    title=m('citation_title');authors=[e['content'] for e in s.select('meta[name="citation_author"]')]
    d={'arxiv':aid,'title':title,'authors':authors,'date':m('citation_date'),'journal':s.select_one('.jref').get_text(' ',strip=True) if s.select_one('.jref') else m('citation_journal_title'), 'publication_evidence':s.select_one('.tablecell.comments').get_text(' ',strip=True) if s.select_one('.tablecell.comments') else '','doi':m('citation_doi'),'url':'https://arxiv.org/abs/'+aid,'abstract':s.select_one('blockquote.abstract').get_text(' ',strip=True) if s.select_one('blockquote.abstract') else '', 'html_available':False}
    links=[a['href'] for a in s.select('a[href]') if '/html/' in a['href']]
    html_url=links[0] if links else 'https://arxiv.org/html/'+aid+'v1'
    if html_url.startswith('/'):html_url='https://arxiv.org'+html_url
    try:
        h=BeautifulSoup(fetch(html_url,'paper_'+aid+'_full.html'),'html.parser');txt=h.get_text(' ',strip=True)
        (ROOT/'references'/('paper_'+aid+'.txt')).write_text(txt)
        d.update(html_available=True,html_url=html_url,full_text_file='references/paper_'+aid+'.txt')
        d['pid_mentions']=sorted(set(re.findall(r'(?:PID|[Pp]rogram(?:me)?(?:\s+ID)?|GO)[\s:#–-]+(?:GO[-\s]*)?(\d{4,5})\b',txt)))
        d['tables']=[t.get_text(' ',strip=True) for t in h.select('table.ltx_tabular')]
    except Exception as e:
        d['full_text_error']=str(e)
        try:
            import io
            from pypdf import PdfReader
            pdf_url='https://arxiv.org/pdf/'+aid
            reader=PdfReader(io.BytesIO(fetch(pdf_url,'paper_'+aid+'.pdf')))
            txt='\n'.join(page.extract_text() or '' for page in reader.pages)
            (ROOT/'references'/('paper_'+aid+'.txt')).write_text(txt)
            d.update(full_text_available=True,pdf_url=pdf_url,full_text_file='references/paper_'+aid+'.txt',pages=len(reader.pages))
        except Exception as pe:d['pdf_error']=str(pe)
    (ROOT/'data'/('paper_'+aid+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2))
    print(aid,title,'PIDs',d.get('pid_mentions'),flush=True);return d
if __name__=='__main__':
    if len(sys.argv)>1:ids=set(sys.argv[1:])
    with concurrent.futures.ThreadPoolExecutor(3) as ex:list(ex.map(one,sorted(ids)))
