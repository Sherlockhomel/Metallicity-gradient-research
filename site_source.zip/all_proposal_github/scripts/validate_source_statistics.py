from github_publish_finalize import read_catalog
"""独立源统计回归：计数、群体、重复源、红移边界及缺失/冲突。"""
from pathlib import Path
import collections,csv,json,xml.etree.ElementTree as ET
from source_statistics import bin_index,choose_redshift,redshift_category

def validate(C,root):
    S=C['source_statistics'];E=S['entries'];tests=[]
    def check(name,ok):tests.append({'test':name,'pass':bool(ok)})
    by_name={r['name']:r for r in E};by_id={r['id']:r for r in E}
    candidates={(p['pid'],t['number']) for p in C['programs'] for t in p['sources'] if t['source_grade']=='A'}
    assigned={(m['pid'],m['target']) for r in E+S['pending'] for m in r['members']}
    check('统计等级总和等于目录',sum(S['grades'].values())==S['proposal_count']==len(C['programs']))
    old=json.loads((root/'data/github_export_baseline.json').read_text())
    check('本次统计不改变项目和逐源等级',[(p['pid'],p['grade'],[(t['number'],t['source_grade']) for t in p['sources']]) for p in C['programs']]==[(p['pid'],p['grade'],[tuple(t) for t in p['sources']]) for p in old['program_grades']])
    check('A指向全部有计入或待拆分记录',assigned==candidates and S['a_pointings']==len(candidates))
    check('不计项目A中的其它等级或背景',all((m['pid'],m['target']) in candidates for r in E for m in r['members']))
    check('独立源ID唯一',len(by_id)==len(E))
    check('每个源均有身份及指向出处',all(r['identity_evidence'] and all(e.get('source') and e.get('locator') for e in r['identity_evidence']) and all(m['evidence'].get('source') and m['evidence'].get('locator') for m in r['members']) for r in E))
    check('源数下限按成员权重相加',S['minimum']==sum(r['minimum'] for r in E)==123 and S['lower_bound'])
    check('Wolfe盘合并4528与5761',{m['pid'] for m in by_name['DLA0817g1']['members']}=={'4528','5761'} and by_name['DLA0817g1']['minimum']==1)
    check('REBELS重复四组仅各计一次',all(sum(r['name']==n for r in E)==1 and len(by_name[n]['members'])==2 for n in ['REBELS-05','REBELS-08','REBELS-29','REBELS-32']))
    r=by_name['J0217-0208'];check('同源逐源数值优于另一计划范围',len(r['members'])==2 and r['redshift']['mode']=='numeric' and r['redshift']['value']==6.204)
    check('8512两对拼接各计一源',all(len(by_name[n]['members'])==2 and by_name[n]['minimum']==1 for n in ['J0148-10916','J0100-09273']) and sum(r['minimum'] for r in E if any(m['pid']=='8512' for m in r['members']))==8)
    check('1554只计西伴星系',sum(r['minimum'] for r in E if any(m['pid']=='1554' for m in r['members']))==1 and by_name['PJ308-21 西伴星系']['redshift']['mode']=='approx')
    check('BR1202只计明确SMG',sum(r['minimum'] for r in E if any(m['pid']=='1220' for m in r['members']))==1 and 'BR1202-0725 SMG' in by_name)
    check('CEERS3和4是不同独立源',all(n in by_name for n in ['CEERS 3','CEERS 4']) and by_name['CEERS 3']['id']!=by_name['CEERS 4']['id'])
    r=by_name['CGG-z5 星系群'];check('CGG群体至少6不伪造数值点',r['minimum']==6 and r['lower_bound'] and r['redshift']['mode']=='approx' and 'at least six' in str(r['identity_evidence']))
    check('未拆分YD成员不贡献源数',not any(m['pid']=='7014' and m['target']=='2' for r in E for m in r['members']) and any(g['members'][0]['pid']=='7014' for g in S['pending']))
    numeric=[r for r in E if r['redshift']['mode']=='numeric'];ids=[i for b in S['bins'] for i in b['source_ids']]
    check('直方图数值源只出现一次',len(ids)==len(set(ids))==S['numeric_count'] and set(ids)=={r['id'] for r in numeric})
    check('分箱权重与类别数守恒',sum(sum(b['counts'].values()) for b in S['bins'])==S['numeric_count'] and all(sum(b['counts'].values())==len(b['source_ids']) for b in S['bins']))
    check('范围与共同近似值不进直方图',all(by_id[i]['redshift']['mode']=='numeric' and by_id[i]['minimum']==1 for i in ids))
    interval_ids=[i for g in S['intervals'] for i in g['source_ids']]
    check('区间源逐条唯一及权重守恒',len(interval_ids)==len(set(interval_ids)) and sum(g['minimum'] for g in S['intervals'])==S['interval_minimum']==63)
    check('数值加区间和未放置源数守恒',S['numeric_count']+S['interval_minimum']+sum(by_id[i]['minimum'] for i in S['unplaced'])==S['minimum'])
    check('分箱左闭右开及边界',all(bin_index(z)==b for z,b in [(2.0001,2),(2.99999,2),(3,3),(3.0001,3),(9.999,9),(10,10)]))
    check('范围不取中点',choose_redshift([{'mode':'range','value':[3,7]}])=={'mode':'range','value':[3,7]})
    check('共同近似值不冒充数值',choose_redshift([{'mode':'approx','value':6}])['mode']=='approx')
    check('缺失红移不进数值',choose_redshift([])['mode']=='missing')
    opts=[{'mode':'numeric','value':5,'category':'光谱红移'},{'mode':'numeric','value':5.1,'category':'光谱红移'}]
    check('冲突不取平均',choose_redshift(opts)['mode']=='conflict' and choose_redshift(opts)['value']==[5,5.1])
    check('红移取得方式未说明不冒充光谱',redshift_category('计划明确列出的源红移（保留计划精度）')=='取得方式未说明' and redshift_category('作者团队已发表源表红移；可能近似或特定分量')=='取得方式未说明')
    check('计划估计与光谱单独统计',redshift_category('计划中的近似/选样红移，并非新测量')=='光度/计划估计' and redshift_category('原文谱线红移')=='光谱红移')
    for f,n in [('a_independent_sources.csv',len(E)),('a_pointings.csv',S['a_pointings']),('a_pending_groups.csv',len(S['pending']))]:
        check('CSV行数 '+f,len(list(csv.DictReader((root/'data'/f).open(encoding='utf-8-sig'))))==n)
    check('两张SVG可解析',all(ET.parse(root/'charts'/f).getroot().tag.endswith('svg') for f in ['a_redshift_histogram.svg','a_redshift_intervals.svg']))
    js=(root/'statistics.js').read_text();idx=(root/'index.html').read_text()
    check('统计脚本及本地图表离线加载','statistics.js' in idx and 'fetch(' not in js and 'charts/a_redshift_histogram.svg' in js)
    out={'checked':'2026-10-04','feature':'source_statistics','passed':all(t['pass'] for t in tests),'tests':tests,'source_count_minimum':S['minimum'],'a_pointings':S['a_pointings'],'numeric_redshifts':S['numeric_count'],'interval_source_minimum':S['interval_minimum']}
    (root/'data/source_statistics_validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    return tests

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1];tests=validate(read_catalog(root),root)
    print(json.dumps(tests,ensure_ascii=False,indent=2))
    if not all(t['pass'] for t in tests):raise SystemExit(1)
