from github_package import package
from pathlib import Path
package(Path(__file__).resolve().parents[1])
