import sys,json,concurrent.futures
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from retrieve import fetch,save_json
def one(page):
    q={'service':'Mast.Jwst.Filtered.Nirspec','params':{'columns':'filename,program,observtn,visit_id,targname,targprop,targ_ra,targ_dec,exp_type,grating,filter,effexptm,expstart,expend,category,title,pi_name,date_obs,datamodl','filters':[{'paramName':'exp_type','values':['NRS_IFU']}]},'format':'json','pagesize':10000,'page':page}
    name=f'mast_NRS_IFU_{page}.json';r=json.loads(fetch('https://mast.stsci.edu/api/v0/invoke',name,'POST',{'request':json.dumps(q)}))
    if r.get('status')!='COMPLETE':raise RuntimeError(str(r)[:1000])
    print(page,len(r.get('data',[])),flush=True);return {'file':'references/'+name,'paging':r.get('paging'),'count':len(r.get('data',[]))}
first=one(1);out=[first]
with concurrent.futures.ThreadPoolExecutor(4) as ex:
    out+=list(ex.map(one,range(2,first['paging']['pagesFiltered']+1)))
save_json('mast_nrs_pages.json',out)
