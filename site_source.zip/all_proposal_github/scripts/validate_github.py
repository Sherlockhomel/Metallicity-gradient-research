"""发布副本验收：科研数据保真、链接、无损元数据、项目子路径与体积。"""
from pathlib import Path
import argparse,collections,gzip,hashlib,html,json,re
from github_publish_finalize import signature,read_catalog

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def validate(root,original=None):
    root=Path(root);d=root/'data';c=read_catalog(root);baseline=json.loads((d/'github_export_baseline.json').read_text());manifest=json.loads((d/'github_export_manifest.json').read_text());tests=[]
    def check(name,ok,detail=''):tests.append({'test':name,'pass':bool(ok),'detail':detail})
    for k,v in baseline['signatures'].items():check('原科研内容保真：'+k,signature(c[k])==v)
    check('125详情与2030审计条目保留',len(c['programs'])==125 and len(c['audit'])==2030)
    check('四级及A源统计保持原值',c['stats']['grades']=={'A':31,'B':71,'C':14,'未定级':9} and c['source_statistics']['minimum']==123 and c['source_statistics']['a_pointings']==129)
    js=(d/'catalog.js').read_text();loaded=json.loads(js.split('window.CATALOG=',1)[1].rsplit(';',1)[0].replace('<\\/','</'))
    check('catalog.js与JSON内容完全一致',loaded==c)
    check('MAST无损gzip校验',all(hashlib.sha256(gzip.decompress((root/a['published_file']).read_bytes())).hexdigest()==a['uncompressed_sha256'] and sha(root/a['published_file'])==a['published_sha256'] for a in manifest['compressed_metadata']))
    check('14份MAST分页全部保留',len(manifest['compressed_metadata'])==14)
    check('原始大APT/PDF历史目录未收入',not(root/'history').exists() and not list((root/'references').glob('apt_*.aptx')) and not list((root/'references').glob('proposal_*.pdf')) and not(root/'jwst_ifu_site_source.zip').exists())
    check('独立重建源码和人工数据存在',all((root/p).exists() for p in ['scripts/build_catalog.py','scripts/github_publish_finalize.py','scripts/export_github.py','data/proposal_selection.json','data/source_registry.json','data/independent_sources.json']))
    check('GitHub静态入口与Jekyll禁用文件存在',(root/'index.html').exists() and (root/'.nojekyll').exists())
    app=(root/'app.js').read_text();stats=(root/'statistics.js').read_text()
    check('没有根绝对资源路径，支持仓库子路径',not re.search(r'(?:href|src)="/', ''.join(p.read_text() for p in root.glob('*.html'))) and 'src="charts/' in stats)
    check('APT与PDF使用官方入口',all(p['source'].startswith('https://www.stsci.edu/jwst-program-info/download/jwst/apt/') for p in c['programs']) and "'官方 PDF ↗'" in app and "'references/proposal_'" not in app)
    paths=[]
    def walk(x):
        if isinstance(x,dict):
            for v in x.values():walk(v)
        elif isinstance(x,list):
            for v in x:walk(v)
        elif isinstance(x,str) and x.startswith(('references/','data/')):paths.append(x)
    walk(c)
    missing=sorted({s for s in paths if not(root/s).is_file()})
    check('运行数据中的本地资料链接完整',not missing,missing)
    check('全部审计本地计划解析字段完整',all((root/f'data/program_{a["pid"]}.json').exists() for a in c['audit'] if a['source']))
    missing=[]
    for p in root.glob('*.html'):
        for s in re.findall(r'(?:href|src)="([^"#]+)"',p.read_text()):
            s=html.unescape(s)
            if s.startswith(('https:','http:','data:','mailto:')):continue
            s=s.split('?')[0].split('#')[0]
            if s and not(root/s).exists() and s not in ['github_report.html','downloads/site_source.zip']:missing.append((p.name,s))
    check('静态页面资源和下载链接完整',not missing,missing)
    files=[p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.git' not in p.parts]
    oversized=[str(p.relative_to(root)) for p in files if p.stat().st_size>25*1024*1024]
    check('每个发布文件不超过25MiB',not oversized,oversized)
    check('发布副本没有符号链接',not any(p.is_symlink() for p in root.rglob('*')))
    payload=sum(p.stat().st_size for p in files if p.name!='site_source.zip')
    check('发布资源小于100MiB',payload<100*1024*1024,payload)
    if original and Path(original).exists():check('原完整版关键文件保持原样',all(sha(Path(original)/n)==v for n,v in manifest['preserved_source_hashes'].items()))
    b=json.loads((d/'github_browser_validation.json').read_text()) if (d/'github_browser_validation.json').exists() else {}
    out={'checked':'2026-10-07','passed':all(t['pass'] for t in tests),'tests':tests,'payload_bytes_excluding_source_zip':payload,'original_bytes':manifest['source_bytes'],'largest_file':max(({'file':str(p.relative_to(root)),'bytes':p.stat().st_size} for p in files),key=lambda x:x['bytes']),'browser_passed':b.get('passed'),'browser_checks':len(b.get('tests',[])),'cutoff':c['stats']['cutoff']}
    (d/'github_validation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    e=html.escape;head=(root/'index.html').read_text().split('<main id="main">')[0]
    content=f'''<h1>GitHub精简版与验收报告</h1><p>整理日期2026-10-07；科研快照截至2026-10-03，分级修订2026-10-04。没有重新检索、处理科学数据或发布网站。</p>
<section><h2>大小与保留内容</h2><p>原目录约{manifest['source_bytes']/1024**3:.2f} GiB。发布资源（不含可下载源码ZIP）约{payload/1024**2:.2f} MiB；文件最大约{out['largest_file']['bytes']/1024**2:.2f} MiB。最终ZIP和目录精确大小见<a href="data/github_package_validation.json">打包校验</a>。</p><p>APT/PDF改用官方链接；大原始文件、原完整ZIP及历史版本留在all_proposal。14份MAST原始响应无损gzip，论文文本、书目、全部2029份计划解析JSON、审计和人工摘录保留。JSON去除空白，不删减研究字段。</p></section>
<section><h2>科研信息保持</h2><p>125个目录项目，2030个候选审计条目；A31/B71/C14/未定级9。至少123个独立A研究源，对照129条A指向，60个数值红移和至少63个范围/近似源。科研数据保真摘要与来源见<a href="data/github_export_baseline.json">导出基准</a>和<a href="data/github_export_manifest.json">精简清单</a>。</p></section>
<section><h2>验收</h2><p>发布版数据和链接检查：{'通过' if out['passed'] else '未通过'}（{len(tests)}项）。浏览器检查：{'通过（'+str(len(b.get('tests',[])))+'项）' if b.get('passed') else '尚未执行本副本实际浏览器检查'}。<a href="data/github_validation.json">数据与链接验收</a> · <a href="data/github_browser_validation.json">浏览器记录</a>。file://仅做静态检查；本次实际浏览器使用本地HTTP预览和仓库子路径。</p><div class="tablewrap"><table><thead><tr><th>检查</th><th>结果</th></tr></thead><tbody>{''.join('<tr><td>'+e(t['test'])+'</td><td>'+('通过' if t['pass'] else '失败')+'</td></tr>' for t in tests)}</tbody></table></div></section>
<section><h2>上传与修改</h2><p><a href="GITHUB_GUIDE.md">GitHub发布步骤</a> · <a href="UPDATE_GUIDE.md">修改与离线重建</a> · <a href="downloads/site_source.zip">本精简版源码ZIP</a>。上传解压后的文件，让index.html位于仓库根目录。</p></section>'''
    (root/'github_report.html').write_text(re.sub(r'<title>.*?</title>','<title>GitHub精简版与验收报告</title>',head)+'<main id="main" class="reading">'+content+'</main><footer>精简副本2026-10-07 · 科研快照2026-10-03</footer></body></html>')
    print(json.dumps({'passed':out['passed'],'checks':len(tests),'payload_MiB':round(payload/1024**2,2),'failed':[t for t in tests if not t['pass']]},ensure_ascii=False,indent=2))
    if not out['passed']:raise SystemExit(1)
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--original',type=Path);a=p.parse_args();root=Path(__file__).resolve().parents[1];validate(root,a.original or root.parent/'all_proposal')
