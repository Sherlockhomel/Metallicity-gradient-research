# GitHub精简版修改与更新

浏览无需安装；重建使用Python 3.10或更新版本，已有缓存重建只依赖标准库。外部官方资料链接需要网络。本副本维护科研快照2026-10-03和分级日期2026-10-04；导出日期2026-10-07不表示重新检索。

## 修改数据

- 外观styles.css，首页index.html，目录与详情app.js，统计statistics.js。
- 分类、源类型、共同红移范围与项目说明：data/proposal_selection.json。
- 已测逐源红移、规范名和别名：data/source_registry.json。共同范围不应编造成逐源精确红移。
- 独立A源合并、拆分与群体下限：data/independent_sources.json。
- 论文方法、结果与出处：data/paper_reviews.json；发表信息：data/publication_reviews.json。
- 分类与审计页由scripts/pages.py生成；本源码说明页由scripts/github_publish_finalize.py生成。

## 在本目录离线重建

```
python scripts/build_catalog.py
python scripts/pages.py
python scripts/report.py
python scripts/validate.py
python scripts/validate_github.py
python scripts/report.py
python scripts/package.py
```

build_catalog.py可直接读取references/*.json.gz，按data/github_archive_order.json保留原快照的读取顺序，确保重复产品去重选择、曝光时间和日期一致；无需下载科学FITS或原始APT。每次构建后自动规范APT/PDF官方链接、MAST压缩缓存链接，并生成正常catalog.js用于浏览，完整页面JSON保存为data/catalog.json.gz用于下载，保持双击可用。

不要只修改生成的catalog.json或catalog.js，否则下次重建会覆盖。修改人工数据后必须运行构建脚本。新增源或主动修订科研结论时，应同步更新科研验收基准；data/github_export_baseline.json记录本次精简前的科研快照，用于本次无损导出检查，不是将来的新研究结论。

scripts/report.py保留原科研整理报告；scripts/validate_github.py检查发布版链接、压缩缓存和文件尺寸并生成github_report.html；data/github_browser_validation.json只记录实际执行过的浏览器检查，重建不自动证明浏览器检查通过。package.py最后生成downloads/site_source.zip并校验CRC。

## 从完整版再次导出

```
python scripts/export_github.py --source ../all_proposal --output ../all_proposal_github_new
```

输出目录必须是新目录，防止覆盖用户后续修改；导出不修改源目录。原APT/PDF和历史版本仍在完整版。完整检索脚本源码保留在scripts中，但重新检索会产生大量原始缓存，不应在发布目录中运行；如需新快照，先在新的完整版目录执行检索，复核后再导出。
