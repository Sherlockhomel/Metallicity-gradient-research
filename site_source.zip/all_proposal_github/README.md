# Metallicity Gradient Research

静态JWST NIRSpec IFU金属丰度研究目录。125个计划详情、A/B/C/未定级统计、独立A源及红移图、论文与检索审计。

双击[index.html](index.html)即可本地查看；也可按[GitHub Pages上传说明](GITHUB_GUIDE.md)发布。上传本目录内的文件，让index.html位于仓库根目录；首次上传建议使用GitHub Desktop，避免逐批处理大量文件。

APT/PDF采用官方链接，MAST元数据无损压缩。可编辑数据及Python构建脚本保留，见[修改指南](UPDATE_GUIDE.md)。[精简验收报告](github_report.html)与[网站及源码ZIP](downloads/site_source.zip)附于本目录。

检索快照2026-10-03；评级修订2026-10-04；本次精简2026-10-07。原始完整版all_proposal保留，没有上传或发布网站。
