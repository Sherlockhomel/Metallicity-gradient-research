# Metallicity Gradient Research

静态JWST NIRSpec IFU金属丰度研究目录。125个计划详情、A/B/C/未定级统计、独立A源及红移图、论文与检索审计。

双击[index.html](index.html)即可本地查看；也可按[GitHub Pages上传说明](GITHUB_GUIDE.md)发布。上传本目录内的文件，让index.html位于仓库根目录；首次上传建议使用GitHub Desktop，避免逐批处理大量文件。

APT/PDF采用官方链接，MAST元数据无损压缩。可编辑数据及Python构建脚本保留，见[修改指南](UPDATE_GUIDE.md)。[精简验收报告](github_report.html)与[网站及源码ZIP](downloads/site_source.zip)附于本目录。

检索快照2026-10-03；评级修订2026-10-04；本次精简2026-10-07。原始完整版all_proposal保留，没有上传或发布网站。

<!-- A_GRADIENT_GUIDE -->
## A 类文献及统一源统计（2026-10-12）

31个A计划；110个去重科学目标：26径向、11仅二维／分量、73未检索到空间气相丰度。另有4个群体／视场，CGG-z5至少6成员单列。前两类必须有对应本源的原文结果；整体、运动学、SED和未来研究不等于空间气相丰度。未检索到只代表截至检索日的公开检索结果。

`data/independent_sources.json`是研究目录、红移图与文献唯一的规范源映射。明确CRISTAL别名及拼接合并；10555四个位置作为一个身份解释未定的视场，不算四个独立A星系。源数由映射自动生成，不手填页面。数值、近似值、范围与冲突分开，不取中点或平均。原ABC分级、观测条件和计划检索日期保持不变；历史快照在完整版history/2026-10-12-before-three-literature-states及对应-github目录。

编辑`data/a_gradient_literature.json`：sources.source_id对应规范映射；studies.paper_id指向papers.id。结果必须给分量、诊断、测值/误差/单位、章节表图与限制；没有定量值时明确说明。data_pids为论文实际使用的数据计划，不能用该源所有关联PID代替。预印本与发表版共用一个论文ID。sources仅允许radial/spatial/not_found；groups不硬分配到独立目标统计。原文无法访问或身份对应不明的候选保留审计，不计已有成果。旧源ID放alias_source_ids或merged_source_ids，保持旧详情链接。

扩展介绍：sources[].summary写源级研究总览（约180–300字），studies[].summary写该论文对本源的研究（约200–400字）；summary_checked记录复读日期。特定目标方法与论文通用介绍不同，可在studies[].diagnostics、studies[].method写逐源覆盖；优先显示这些字段。先说明对象、方法，再写结果、意义与限制。原数值result、分类理由reason和出处locator均保留；summary缺失时沿用旧说明。界面和搜索读取同一文本，勿手填生成网页。data/paper_summary_review.json保存原文哈希、关联及引用／方法更正。

离线重建：

```sh
python scripts/build_catalog.py
python scripts/pages.py
python scripts/validate_gradients.py
python scripts/validate_paper_summaries.py
python scripts/validate.py
python scripts/package.py
```

数据导出继续生成`data/a_gradient_sources.csv`、`a_gradient_proposals.csv`、`a_gradient_papers.csv`和检索CSV，网页不列技术下载按钮。核查记录在gradient_report.html及data/gradient_validation.json；原检索响应、计划引用与复查记录在references/gradient_literature/review_2026-10-12。`scripts/retrieve_gradient_literature.py --export-queries`导出查询；`--refresh-bibliography`查官方书目；`--arxiv-search`查候选；`scripts/fetch_gradient_papers.py`保存原文（需requests/beautifulsoup4、PDF回退需pdftotext）。检索脚本不自动认定成果。书目可能滞后，不能把零篇当成没有相关论文。

本次扩写60个源／视场总览、121条逐篇介绍，覆盖29篇既有关联论文；未开展新检索。修改前完整版与GitHub版保存在完整版history/2026-10-12-before-expanded-paper-summaries及对应-github目录。扩写验收见paper_summary_report.html、data/paper_summary_validation.json及data/paper_summary_browser_validation.json。重建后可运行`python scripts/verify_three_state_rebuild.py`比较data/paper_summary_rebuild_baseline.json；旧data/three_state_rebuild_baseline.json保留。后续主动改变数据时另立新基准。旧保真基准保持，source_statistics变更由data/source_mapping_revision.json单独验收，其它科学字段逐项对比。浏览器验收在data/gradient_browser_validation.json；浏览器限制file://时仅记录静态检查，不冒充双击实测。网站未上传或发布。
<!-- /A_GRADIENT_GUIDE -->
