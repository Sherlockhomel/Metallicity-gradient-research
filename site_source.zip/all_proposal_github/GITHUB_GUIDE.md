# GitHub Pages上传说明

本目录是独立可浏览、可重建的精简发布副本。科研快照截至2026-10-03，分级修订2026-10-04；整理日期2026-10-07。原all_proposal完整资料保留，没有上传或发布。

1. 创建一个Public仓库，例如metallicity-gradient-research。
2. 用GitHub Desktop提交本目录内容，或在GitHub网页Add file → Upload files上传。index.html必须位于仓库根目录，data、charts、references、scripts、downloads保持同级结构。首次提交较多文件时，GitHub Desktop更方便；网页上传可按文件夹分批进行。
3. 保留空的.nojekyll文件；不要上传符号链接、Python缓存、原版APT/PDF和history。
4. Settings → Pages → Source选择Deploy from a branch，Branch选main，Folder选/(root)，Save。
5. 发布完成后点击Visit site。网址通常为https://你的用户名.github.io/metallicity-gradient-research/。
6. 验证等级卡、搜索、任一详情、红移图、审计和CSV下载；项目子路径下也应正常工作。

downloads/site_source.zip是本发布版的源码下载副本，可以一并上传以支持网站的下载入口。ZIP不直接作为Pages入口。完整版的大ZIP留在本地，若需要公开分发可另上传GitHub Releases并修改相关下载入口。

所有文件的实际大小、CRC和SHA256见data/github_package_validation.json；功能与链接检查见github_report.html。Github设置帮助：https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
